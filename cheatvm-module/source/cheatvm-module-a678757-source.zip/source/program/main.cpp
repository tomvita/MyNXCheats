#include "lib.hpp"
#include "nn/fs.hpp"
#include "nn/os.hpp"
#include "vm/stratosphere.hpp"
#include "vm/dmnt_cheat_vm.hpp"
#include "vm/cheats.hpp"
#include "vm/dmnt_cheat_api.hpp"
#include "cvm.hpp"
#include "menu.hpp"

#include <cstdio>
#include <cstring>
#include <cstdarg>

/*
 * dmnt's cheat VM inside the game. Everything is in /atmosphere/contents/<TID>/cheats/: the
 * cheat file <BID>.txt (the one dmnt, Breeze and Eden use), cheatvm_toggles.txt (dmnt's
 * format, but our own file: dmnt rewrites toggles.txt from its own state when the game
 * closes), cheatvm.ini, cheatvm_log.txt and cheatvm_status.txt. The cheat file and toggles
 * are read again every second; a change applies at once.
 */

namespace nn::fs {
    Result DeleteFile(char const *path);
}

namespace nn::hid {
    struct NpadBaseState {
        s64 sampling_number;
        u64 buttons;
        s32 lx, ly, rx, ry;
        u32 attributes;
        u32 reserved;
    };
    struct NpadFullKeyState : NpadBaseState {};
    struct NpadHandheldState : NpadBaseState {};
    struct NpadJoyDualState : NpadBaseState {};
    struct NpadJoyLeftState : NpadBaseState {};
    struct NpadJoyRightState : NpadBaseState {};
    void GetNpadState(NpadFullKeyState *out, const u32 &id);
    void GetNpadState(NpadHandheldState *out, const u32 &id);
    void GetNpadState(NpadJoyDualState *out, const u32 &id);
    void GetNpadState(NpadJoyLeftState *out, const u32 &id);
    void GetNpadState(NpadJoyRightState *out, const u32 &id);
    int GetNpadStates(NpadFullKeyState *out, int count, const u32 &id);
    int GetNpadStates(NpadHandheldState *out, int count, const u32 &id);
    int GetNpadStates(NpadJoyDualState *out, int count, const u32 &id);
    int GetNpadStates(NpadJoyLeftState *out, int count, const u32 &id);
    int GetNpadStates(NpadJoyRightState *out, int count, const u32 &id);
}

extern "C" void nnMain();

/* Buttons as the game last read them, per style and controller (ids 0-7, 8 = handheld).
   Calling these functions ourselves aborts for any controller the game did not enable. */
namespace {
    volatile u64 g_seen[5][9];
    volatile u32 g_reads;

    void Seen(int style, u32 id, u64 buttons) {
        const u32 slot = id == 0x20 ? 8 : id;
        if (slot < 9)
            g_seen[style][slot] = buttons;
        g_reads = g_reads + 1;
    }

    /* While the menu is open the game sees no buttons and centred sticks. */
    template <typename T>
    void Hide(T *out, int count) {
#if CVM_UI
        if (cvm::menu::IsOpen())
            for (int i = 0; i < count; i++) {
                out[i].buttons = 0;
                out[i].lx = out[i].ly = out[i].rx = out[i].ry = 0;
            }
#else
        (void)out;
        (void)count;
#endif
    }
}

#define NPAD_HOOKS(Name, Type, style)                                              \
    HOOK_DEFINE_TRAMPOLINE(Name##One) {                                            \
        static void Callback(nn::hid::Type *out, const u32 &id) {                 \
            Orig(out, id);                                                         \
            Seen(style, id, out->buttons);                                         \
            Hide(out, 1);                                                          \
        }                                                                          \
    };                                                                             \
    HOOK_DEFINE_TRAMPOLINE(Name##Many) {                                           \
        static int Callback(nn::hid::Type *out, int count, const u32 &id) {       \
            const int n = Orig(out, count, id);                                    \
            if (n > 0)                                                             \
                Seen(style, id, out[0].buttons);                                   \
            Hide(out, n);                                                          \
            return n;                                                              \
        }                                                                          \
    };

NPAD_HOOKS(FullKey, NpadFullKeyState, 0)
NPAD_HOOKS(Handheld, NpadHandheldState, 1)
NPAD_HOOKS(JoyDual, NpadJoyDualState, 2)
NPAD_HOOKS(JoyLeft, NpadJoyLeftState, 3)
NPAD_HOOKS(JoyRight, NpadJoyRightState, 4)

namespace cvm {
    u64 RawKeys() {
        u64 keys = 0;
        for (auto &style : g_seen)
            for (auto &b : style)
                keys |= b;
        return keys;
    }

    /* What key cheats see: nothing while the menu has the buttons. */
    u64 KeysHeld() {
#if CVM_UI
        if (menu::IsOpen())
            return 0;
#endif
        return RawKeys();
    }

    namespace {
        bool g_log_ok = false;
        s64 g_log_pos = 0;
    }
    char g_dir[0x80];      /* cvm:/atmosphere/contents/<TID>/cheats/ */

    void Log(const char *fmt, ...) {
        if (!g_log_ok)
            return;
        char line[512];
        va_list va;
        va_start(va, fmt);
        int n = vsnprintf(line, sizeof(line) - 1, fmt, va);
        va_end(va);
        if (n < 0)
            return;
        if (n > (int)sizeof(line) - 2)
            n = sizeof(line) - 2;
        line[n++] = '\n';
        char path[0x100];
        snprintf(path, sizeof(path), "%scheatvm_log.txt", g_dir);
        nn::fs::FileHandle h;
        if (R_FAILED(nn::fs::OpenFile(&h, path, nn::fs::OpenMode_Write | nn::fs::OpenMode_Append)))
            return;
        nn::fs::WriteFile(h, g_log_pos, line, n, nn::fs::WriteOption::CreateOption(nn::fs::WriteOptionFlag_Flush));
        g_log_pos += n;
        nn::fs::CloseFile(h);
    }

    void StartLog() {
        char path[0x100];
        snprintf(path, sizeof(path), "%scheatvm_log.txt", g_dir);
        nn::fs::DeleteFile(path);
        g_log_ok = R_SUCCEEDED(nn::fs::CreateFile(path, 0));
    }
}

namespace {
    using ams::dmnt::cheat::CheatProcessMetadata;
    using ams::dmnt::cheat::CheatEntry;

    ams::dmnt::cheat::impl::CheatVirtualMachine g_vm;
    CheatProcessMetadata g_meta;
    bool g_program_loaded = false;

    /* Cheats as parsed, and what the VM is given (ASM cheats reordered). */
    cvm::CheatSet g_set;
    bool g_have_set = false;
    CheatEntry g_run[cvm::MaxCheatCount];
    bool g_reordered[cvm::MaxCheatCount];

    /* ASM cheats that were on at the last load: their originals go back when they go off. */
    struct AsmOn {
        char name[0x40];
        u64 offset;
        u32 original;
    };
    AsmOn g_asm_on[cvm::MaxCheatCount];
    size_t g_asm_on_count = 0;

    /* Code-patch cheats in Breeze's form (cvm::ParseCodePatch) that were on at the last load,
       one row per patch at its address in the game: when the cheat goes off, the original goes
       back where the word still holds the patch. */
    struct PatchOn {
        char name[0x40];
        u64 address;
        u32 original;
        u32 hack;
    };
    constexpr size_t MaxPatchOn = 0x400;
    PatchOn g_patch_on[MaxPatchOn];
    size_t g_patch_on_count = 0;
    u32 g_patches_restored = 0;

    /* Breeze split cheats: the [code cave] folder (never in the VM), and the split hooks and
       mod values that were on at the last load, undone when they go off. */
    cvm::CaveSet g_caves;
    struct WasOn {
        char name[0x40];
        bool split;
        cvm::SplitHook hook;
        bool has_mod;
        char mod[0x40];
    };
    WasOn g_was_on[cvm::MaxCheatCount];
    size_t g_was_on_count = 0;
    u32 g_caves_filled = 0, g_caves_restored = 0;

    char g_cheat_text[0x20000];
    char g_toggle_text[0x8000];
    char g_cheat_path[0x100];
    char g_toggle_path[0x100];
    u64 g_files_hash = 0;
    char g_load_error[160];
    bool g_no_cheat_file = false;

    /* Whole file into buf (zero-terminated); -1 when it can't be read. */
    long ReadText(const char *path, char *buf, size_t cap) {
        nn::fs::FileHandle h;
        buf[0] = 0;
        if (R_FAILED(nn::fs::OpenFile(&h, path, nn::fs::OpenMode_Read)))
            return -1;
        long size = 0;
        long got = -1;
        if (R_SUCCEEDED(nn::fs::GetFileSize(&size, h)) && size >= 0 && (size_t)size < cap &&
            R_SUCCEEDED(nn::fs::ReadFile(h, 0, buf, size)))
            got = size;
        nn::fs::CloseFile(h);
        buf[got < 0 ? 0 : got] = 0;
        return got;
    }

    void WriteText(const char *path, const char *text, size_t len) {
        nn::fs::DeleteFile(path);
        if (R_FAILED(nn::fs::CreateFile(path, 0)))
            return;
        nn::fs::FileHandle h;
        if (R_FAILED(nn::fs::OpenFile(&h, path, nn::fs::OpenMode_Write | nn::fs::OpenMode_Append)))
            return;
        nn::fs::WriteFile(h, 0, text, len, nn::fs::WriteOption::CreateOption(nn::fs::WriteOptionFlag_Flush));
        nn::fs::CloseFile(h);
    }

    u64 Fnv(u64 h, const char *s, long n) {
        for (long i = 0; i < n; i++)
            h = (h ^ (u8)s[i]) * 0x100000001B3ull;
        return h;
    }

    /* The main module's build id: the GNU build-id note in its read-only data. */
    bool MainBuildId(u8 (&out)[0x20]) {
        const auto &main = exl::util::GetMainModuleInfo();
        const u8 *p = reinterpret_cast<const u8 *>(main.m_Rodata.m_Start);
        const size_t size = main.m_Rodata.m_Size;
        static const u8 gnu[] = {'G', 'N', 'U', 0};
        for (size_t i = 0; i + 16 + 0x14 <= size; i += 4) {
            u32 namesz, descsz, type;
            std::memcpy(&namesz, p + i, 4);
            if (namesz != 4)
                continue;
            std::memcpy(&descsz, p + i + 4, 4);
            std::memcpy(&type, p + i + 8, 4);
            if (type != 3 || descsz < 8 || descsz > 0x20 || std::memcmp(p + i + 12, gnu, 4) != 0)
                continue;
            std::memset(out, 0, sizeof(out));
            std::memcpy(out, p + i + 16, descsz);
            return true;
        }
        return false;
    }

    bool HookIsCode(u64 main_offset) {
        return cvm::IsExecutable(g_meta.main_nso_extents.base + main_offset);
    }

    bool ReadGame(u64 address, void *out, size_t size) {
        return R_SUCCEEDED(ams::dmnt::cheat::impl::ReadCheatProcessMemoryUnsafe(address, out, size));
    }

    /* Code-patch cheats (cvm::ParseCodePatch): a patch of a cheat that was on and is not any
       more gets the game's instruction back where the word still holds the patch (a word holding
       anything else is left alone); then the rows of the cheats on now. R1 patches use the R1
       the master cheat leaves (cvm::MasterR1), worked out once per load and only when needed. */
    cvm::CodePatch g_patch_parse[cvm::MaxCodePatches];  /* file scope: a function static costs guard code */
    PatchOn g_patch_next[MaxPatchOn];

    void CodePatchesOff(const cvm::CheatSet &set) {
        cvm::CodePatch *patches = g_patch_parse;
        PatchOn *now = g_patch_next;
        size_t now_count = 0;
        u64 r1 = 0;
        bool asked = false, have_r1 = false;
        const u64 bases[4] = {g_meta.main_nso_extents.base, g_meta.heap_extents.base, g_meta.alias_extents.base,
                              g_meta.aslr_extents.base};
        for (size_t i = 1; i < set.count; i++) {
            size_t count = 0;
            if (!set.entries[i].enabled || !cvm::ParseCodePatch(set.entries[i].definition, patches, cvm::MaxCodePatches, count))
                continue;
            for (size_t k = 0; k < count && now_count < MaxPatchOn; k++) {
                u64 address = g_meta.main_nso_extents.base + patches[k].offset;
                if (patches[k].r1) {
                    if (!asked) {
                        asked = true;
                        have_r1 = set.count > 0 && cvm::MasterR1(set.entries[0].definition, bases, ReadGame, r1);
                        if (have_r1)
                            cvm::Log("R1 from the master cheat: %lx", r1);
                        else
                            cvm::Log("code patches in a module: the master cheat gives no R1, left as they are");
                    }
                    if (!have_r1)
                        continue;
                    address += r1;
                }
                PatchOn &p = now[now_count++];
                std::memcpy(p.name, set.entries[i].definition.readable_name, sizeof(p.name));
                p.address = address;
                p.original = patches[k].original;
                p.hack = patches[k].hack;
            }
        }
        for (size_t k = 0; k < g_patch_on_count; k++) {
            const PatchOn &a = g_patch_on[k];
            bool still_on = false;
            for (size_t j = 0; j < now_count && !still_on; j++)
                still_on = now[j].address == a.address && std::strcmp(now[j].name, a.name) == 0;
            u32 word = 0;
            if (still_on || a.hack == a.original || !ReadGame(a.address, &word, sizeof(word)) || word != a.hack)
                continue;
            ams::dmnt::cheat::impl::WriteCheatProcessMemoryUnsafe(a.address, &a.original, sizeof(a.original));
            g_patches_restored++;
            cvm::Log("off: [%s] original %08X back at %lx", a.name, a.original, a.address);
        }
        std::memcpy(g_patch_on, now, now_count * sizeof(PatchOn));
        g_patch_on_count = now_count;
    }

    bool Exists(const char *path) {
        nn::fs::FileHandle h;
        if (R_FAILED(nn::fs::OpenFile(&h, path, nn::fs::OpenMode_Read)))
            return false;
        nn::fs::CloseFile(h);
        return true;
    }

    void FindCheatFile() {
        const u8 *b = g_meta.main_nso_module_id;
        char bid[17];
        snprintf(bid, sizeof(bid), "%02X%02X%02X%02X%02X%02X%02X%02X", b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]);
        char bid_lower[17];
        for (int i = 0; i < 17; i++)
            bid_lower[i] = (bid[i] >= 'A' && bid[i] <= 'F') ? bid[i] + 32 : bid[i];
        snprintf(g_toggle_path, sizeof(g_toggle_path), "%scheatvm_toggles.txt", cvm::g_dir);
        snprintf(g_cheat_path, sizeof(g_cheat_path), "%s%s.txt", cvm::g_dir, bid_lower);
        if (Exists(g_cheat_path))
            return;
        /* Atmosphere's upper-case name; watched even when missing, so a file put there later is picked up. */
        snprintf(g_cheat_path, sizeof(g_cheat_path), "%s%s.txt", cvm::g_dir, bid);
    }

    char g_ini[0x800];

    /* key = value in cheatvm.ini (read by ReloadIfChanged), or nullptr. */
    const char *IniValue(const char *key) {
        const size_t len = std::strlen(key);
        for (const char *k = std::strstr(g_ini, key); k != nullptr; k = std::strstr(k + 1, key)) {
            if (k != g_ini && k[-1] != '\n')
                continue;
            const char *v = k + len;
            while (*v == ' ' || *v == '\t')
                v++;
            if (*v != '=')
                continue;
            v++;
            while (*v == ' ' || *v == '\t')
                v++;
            return v;
        }
        return nullptr;
    }

    /* cheatvm.ini: enabled_by_default = 1 starts [name] cheats on, as dmnt does.
       Off unless set: Breeze files hold "off" variants next to the cheats they undo. */
    bool EnabledByDefault() {
        const char *v = IniValue("enabled_by_default");
        return v != nullptr && *v == '1';
    }

#if CVM_UI
    /* cheatvm.ini, menu settings: menu_keys = L+R+DDown, menu_font = system|builtin,
       menu_banner = 1|0, menu_flip = auto|1|0. */
    void ReadMenuConfig() {
        cvm::menu::Config c = cvm::menu::GetConfig();
        c.open_keys = (1ull << 6) | (1ull << 7) | (1ull << 15);
        if (const char *v = IniValue("menu_keys")) {
            if (const u64 keys = cvm::menu::ParseKeys(v))
                c.open_keys = keys;
            else
                cvm::Log("cheatvm.ini: menu_keys not understood, L+R+DDown kept");
        }
        const char *v = IniValue("menu_font");
        c.system_font = v == nullptr || std::strncmp(v, "builtin", 7) != 0;
        v = IniValue("menu_banner");
        c.banner = v == nullptr || *v != '0';
        v = IniValue("menu_flip");
        c.flip = v == nullptr || std::strncmp(v, "auto", 4) == 0 ? 0 : *v == '1' ? 1 : -1;
        c.test_crop_w = c.test_crop_h = 0;
        if ((v = IniValue("menu_test_crop")) != nullptr)
            std::sscanf(v, "%dx%d", &c.test_crop_w, &c.test_crop_h);
        cvm::menu::SetConfig(c);
    }
#endif

    /* cheatvm_toggles.txt naming every cheat, as on or off in set. */
    void WriteToggles(const cvm::CheatSet &set) {
        static char text[0x4000];
        size_t n = 0;
        for (size_t i = 1; i < set.count && n < sizeof(text) - 0x60; i++) {
            const auto &e = set.entries[i];
            if (e.definition.num_opcodes == 0 || cvm::IsFolderMarker(e.definition))
                continue;
            n += snprintf(text + n, sizeof(text) - n, "[%s]\n%s\n\n", e.definition.readable_name, e.enabled ? "on" : "off");
        }
        WriteText(g_toggle_path, text, n);
    }

    /* No cheatvm_toggles.txt yet: write one naming every cheat, so turning one on is changing a word. */
    void WriteTogglesTemplate(const cvm::CheatSet &set) {
        WriteToggles(set);
        cvm::Log("wrote %s: every cheat listed, change off to on", g_toggle_path + 4);
    }

    void WriteStatus() {
        static char text[0x8000];
        size_t n = 0;
        auto put = [&](const char *fmt, ...) {
            if (n >= sizeof(text) - 1)
                return;
            va_list va;
            va_start(va, fmt);
            const int w = vsnprintf(text + n, sizeof(text) - n, fmt, va);
            va_end(va);
            if (w > 0)
                n = std::min(n + (size_t)w, sizeof(text) - 1);
        };
        const u8 *b = g_meta.main_nso_module_id;
        put("cheatvm " CHEATVM_VERSION " status\nprogram %016lX build %02X%02X%02X%02X%02X%02X%02X%02X\n", g_meta.program_id, b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]);
        put("cheat file %s\ntoggles %s\n", g_cheat_path + 4, g_toggle_path + 4);
        put("main %lx+%lx heap %lx+%lx alias %lx+%lx aslr %lx+%lx\n", g_meta.main_nso_extents.base, g_meta.main_nso_extents.size,
            g_meta.heap_extents.base, g_meta.heap_extents.size, g_meta.alias_extents.base, g_meta.alias_extents.size,
            g_meta.aslr_extents.base, g_meta.aslr_extents.size);
        if (g_load_error[0])
            put("NOT RUNNING: %s\n", g_load_error);
        else
            put("running %zu of 1024 opcodes\n", g_vm.GetProgramSize());
        const auto &m = cvm::g_mem;
        put("reads %lu (failed %lu) writes %lu (failed %lu) code writes %lu (already set %lu) vm faults %lu pause opcodes %u\n",
            m.reads, m.read_faults, m.writes, m.write_faults, m.code_writes, m.code_unchanged, m.vm_faults, m.pause_requests);
        if (cvm::RefreshingCode())
            put("code page refreshes %lu (failed %lu): ic ivau does not reach every core here\n", m.code_refreshes, m.refresh_failures);
        put("code cave folder: %zu cheats; caves filled %u, originals restored %u\n", g_caves.count, g_caves_filled, g_caves_restored);
        put("code-patch cheats: %zu patches on; originals restored %u\n", g_patch_on_count, g_patches_restored);
        if (g_have_set) {
            for (size_t i = 0; i < g_set.count; i++) {
                const auto &e = g_set.entries[i];
                if (e.definition.num_opcodes == 0)
                    continue;
                if (cvm::IsFolderMarker(e.definition))
                    put("--- %s\n", e.definition.readable_name);
                else
                    put("%s %s%s%s %u opcodes%s\n", e.enabled ? "on " : "off", i == 0 ? "{" : "[", e.definition.readable_name, i == 0 ? "}" : "]",
                        g_run[i].definition.num_opcodes, g_reordered[i] ? ", ASM cave first" : "");
            }
        }
        char path[0x100];
        snprintf(path, sizeof(path), "%scheatvm_status.txt", cvm::g_dir);
        WriteText(path, text, n);
    }

    /* Writes every store of a cave cheat (or off / default value) into the game. */
    bool WriteStores(const ams::dmnt::cheat::CheatDefinition &def) {
        cvm::Store stores[0x60];
        size_t count = 0;
        if (!cvm::Stores(def, stores, 0x60, count)) {
            cvm::Log("[%s]: not plain stores, not written", def.readable_name);
            return false;
        }
        for (size_t i = 0; i < count; i++) {
            const cvm::Store &st = stores[i];
            const u64 base = st.region == 0 ? g_meta.main_nso_extents.base : st.region == 1 ? g_meta.heap_extents.base : 0;
            if (base == 0)
                return false;
            ams::dmnt::cheat::impl::WriteCheatProcessMemoryUnsafe(base + st.address, &st.value, st.width);
        }
        return true;
    }

    bool CaveFilled(const cvm::SplitHook &h) {
        u32 now = 0;
        ams::dmnt::cheat::impl::ReadCheatProcessMemoryUnsafe(g_meta.main_nso_extents.base + h.cave, &now, sizeof(now));
        return now == h.first;
    }

    bool IsOn(const cvm::CheatSet &set, const char *name) {
        for (size_t i = 1; i < set.count; i++)
            if (set.entries[i].enabled && std::strcmp(set.entries[i].definition.readable_name, name) == 0)
                return true;
        return false;
    }

    /* Breeze split cheats, as Breezehand does them: a split hook that is on gets its cave
       filled; one that went off gets its original back ("<name> (off)" or the first form's
       Else); a mod value that went off, with no other value of that mod on, gets the mod's
       "(default)" written back. */
    void SplitCheats(const cvm::CheatSet &set) {
        for (size_t k = 0; k < g_was_on_count; k++) {
            const WasOn &w = g_was_on[k];
            if (IsOn(set, w.name))
                continue;
            if (w.split) {
                if (w.hook.has_original) {
                    ams::dmnt::cheat::impl::WriteCheatProcessMemoryUnsafe(g_meta.main_nso_extents.base + w.hook.hook, &w.hook.original, 4);
                    g_caves_restored++;
                    cvm::Log("off: [%s] original %08X back at main+%lx", w.name, w.hook.original, w.hook.hook);
                } else {
                    char off[0x48];
                    snprintf(off, sizeof(off), "%s (off)", cvm::LabelKey(w.name));
                    const auto *d = cvm::FindCave(g_caves, off);
                    if (d != nullptr && WriteStores(*d)) {
                        g_caves_restored++;
                        cvm::Log("off: [%s] wrote [%s]", w.name, d->readable_name);
                    } else {
                        cvm::Log("off: [%s] has no [%s]; hook left in place", w.name, off);
                    }
                }
            }
            if (w.has_mod) {
                bool other_on = false;
                const ams::dmnt::cheat::CheatDefinition *def = nullptr;
                for (size_t i = 1; i < set.count; i++) {
                    char mod[0x40];
                    if (!cvm::ModIn(set, i, mod) || std::strcmp(mod, w.mod) != 0)
                        continue;
                    other_on = other_on || set.entries[i].enabled;
                    if (cvm::IsDefaultValue(set.entries[i].definition.readable_name))
                        def = &set.entries[i].definition;
                }
                if (!other_on && def != nullptr && WriteStores(*def))
                    cvm::Log("off: [%s] wrote the default [%s]", w.name, def->readable_name);
            }
        }
        g_was_on_count = 0;
        for (size_t i = 1; i < set.count; i++) {
            const auto &e = set.entries[i];
            if (!e.enabled)
                continue;
            WasOn &w = g_was_on[g_was_on_count];
            w = WasOn{};
            w.split = cvm::ParseSplitHook(e.definition, w.hook);
            w.has_mod = cvm::ModIn(set, i, w.mod);
            if (!w.split && !w.has_mod)
                continue;
            std::memcpy(w.name, e.definition.readable_name, sizeof(w.name));
            g_was_on_count++;
            if (w.split && !CaveFilled(w.hook)) {
                const auto *d = cvm::FindCave(g_caves, e.definition.readable_name);
                if (d != nullptr && WriteStores(*d)) {
                    g_caves_filled++;
                    cvm::Log("on: [%s] cave filled at main+%lx", w.name, w.hook.cave);
                } else {
                    cvm::Log("on: [%s] has no cave in [code cave]; its hook stays off", w.name);
                }
            }
        }
    }

#if CVM_UI
    /* The list the menu shows, as just loaded. */
    void PublishMenu(size_t on, size_t total) {
        static cvm::menu::Snapshot s;
        static char mods[cvm::menu::MaxItems][0x40];
        u16 groups = 0;
        s.count = 0;
        for (size_t i = 1; i < g_set.count && s.count < cvm::menu::MaxItems; i++) {
            const auto &e = g_set.entries[i];
            if (e.definition.num_opcodes == 0)
                continue;
            auto &it = s.items[s.count++];
            std::memcpy(it.name, e.definition.readable_name, sizeof(it.name));
            it.name[sizeof(it.name) - 1] = 0;
            it.on = e.enabled;
            /* Values of one mod share a group number, for the menu's radio. */
            it.group = 0;
            char mod[0x40] = {};
            if (cvm::ModIn(g_set, i, mod)) {
                for (u32 j = 0; j + 1 < s.count && it.group == 0; j++)
                    if (s.items[j].group != 0 && std::strcmp(mods[j], mod) == 0)
                        it.group = s.items[j].group;
                if (it.group == 0)
                    it.group = ++groups;
            }
            std::memcpy(mods[s.count - 1], mod, sizeof(mod));
            it.kind = !cvm::IsFolderMarker(e.definition) ? cvm::menu::Cheat
                      : e.definition.opcodes[0] == 0x20000001 ? cvm::menu::FolderClose
                                                               : cvm::menu::FolderOpen;
        }
        if (g_load_error[0])
            snprintf(s.status, sizeof(s.status), "not running: %s", g_load_error);
        else
            snprintf(s.status, sizeof(s.status), "%zu on, %zu of 1024 opcodes", on, total);
        const u8 *b = g_meta.main_nso_module_id;
        snprintf(s.game, sizeof(s.game), "program %016lX\nbuild %02X%02X%02X%02X%02X%02X%02X%02X\ncheatvm " CHEATVM_VERSION, g_meta.program_id, b[0], b[1], b[2], b[3],
                 b[4], b[5], b[6], b[7]);
        s.hint[0] = 0;
        if (g_no_cheat_file)
            snprintf(s.hint, sizeof(s.hint), "Put the cheat file on the SD card (emulator: its sdmc folder) at\n%.180s", g_cheat_path + 4);
        cvm::menu::Publish(s);
    }

    void ReloadIfChanged();

    /* What the menu turned on or off: into cheatvm_toggles.txt, then loaded like any change. */
    void ApplyMenuRequests() {
        cvm::menu::Request req[64];
        const size_t n = cvm::menu::TakeRequests(req, 64);
        if (n == 0 || !g_have_set)
            return;
        for (size_t k = 0; k < n; k++) {
            cvm::CheatEntry *e = nullptr;
            size_t at = 0;
            for (size_t i = 1; i < g_set.count && e == nullptr; i++)
                if (std::strcmp(g_set.entries[i].definition.readable_name, req[k].name) == 0 && !cvm::IsFolderMarker(g_set.entries[i].definition)) {
                    e = &g_set.entries[i];
                    at = i;
                }
            if (e == nullptr) {
                cvm::Log("menu: [%s] is no longer in the cheat file", req[k].name);
                continue;
            }
            e->enabled = req[k].on;
            cvm::Log("menu: [%s] %s", req[k].name, req[k].on ? "on" : "off");
            /* One value of a mod at a time, as Breezehand does. */
            char mod[0x40];
            if (req[k].on && cvm::ModIn(g_set, at, mod))
                for (size_t i = 1; i < g_set.count; i++) {
                    char other[0x40];
                    auto &o = g_set.entries[i];
                    if (&o != e && o.enabled && cvm::ModIn(g_set, i, other) && std::strcmp(mod, other) == 0)
                        o.enabled = false;
                }
        }
        WriteToggles(g_set);
        ReloadIfChanged();
    }
#endif

    /* Reads the cheat file and toggles; when either changed, loads them into the VM. */
    void ReloadIfChanged() {
        FindCheatFile();
        const long cheat_len = ReadText(g_cheat_path, g_cheat_text, sizeof(g_cheat_text));
        long toggle_len = ReadText(g_toggle_path, g_toggle_text, sizeof(g_toggle_text));
        if (toggle_len < 0 && cheat_len >= 0) {
            /* First run with this file: start from dmnt's toggles.txt, the choices made in Breeze. */
            char dmnt_toggles[0x100];
            snprintf(dmnt_toggles, sizeof(dmnt_toggles), "%stoggles.txt", cvm::g_dir);
            toggle_len = ReadText(dmnt_toggles, g_toggle_text, sizeof(g_toggle_text));
            if (toggle_len >= 0) {
                WriteText(g_toggle_path, g_toggle_text, toggle_len);
                cvm::Log("%s copied from toggles.txt", g_toggle_path + 4);
            }
        }
        {
            char path[0x100];
            snprintf(path, sizeof(path), "%scheatvm.ini", cvm::g_dir);
            if (ReadText(path, g_ini, sizeof(g_ini)) < 0)
                g_ini[0] = 0;
        }
        const bool by_default = EnabledByDefault();
        u64 h = Fnv(0xCBF29CE484222325ull, g_cheat_text, cheat_len < 0 ? 0 : cheat_len);
        h = Fnv(h, g_ini, std::strlen(g_ini));
        h = Fnv(h ^ (u64)cheat_len, g_toggle_text, toggle_len < 0 ? 0 : toggle_len) ^ ((u64)toggle_len << 1) ^ by_default;
        if (h == g_files_hash)
            return;
        g_files_hash = h;

        cvm::CheatSet &set = g_set;
        g_load_error[0] = 0;
        g_caves.count = 0;
        g_no_cheat_file = cheat_len < 0;
        if (cheat_len < 0) {
            std::memset(&set, 0, sizeof(set));
            snprintf(g_load_error, sizeof(g_load_error), "no cheat file");
        } else if (!cvm::ParseCheats(g_cheat_text, cheat_len, set, by_default)) {
            snprintf(g_load_error, sizeof(g_load_error), "cheat file: %s", set.error);
            set.count = 0;
        } else if (cvm::TakeCaveFolder(set, g_caves), toggle_len < 0) {
            WriteTogglesTemplate(set);
        } else if (!cvm::ParseToggles(g_toggle_text, toggle_len, set)) {
            cvm::Log("cheatvm_toggles.txt not understood; using defaults");
        }
        g_have_set = true;

        /* An ASM cheat that was on and now is not gets its original instruction back
           (dmnt never restores it; Breeze's Turn off all does the same). */
        for (size_t k = 0; k < g_asm_on_count; k++) {
            const AsmOn &a = g_asm_on[k];
            bool still_on = false;
            for (size_t i = 0; i < set.count && !still_on; i++)
                still_on = set.entries[i].enabled && std::strcmp(set.entries[i].definition.readable_name, a.name) == 0;
            if (!still_on && HookIsCode(a.offset)) {
                ams::dmnt::cheat::impl::WriteCheatProcessMemoryUnsafe(g_meta.main_nso_extents.base + a.offset, &a.original, 4);
                cvm::Log("off: [%s] original %08X back at main+%lx", a.name, a.original, a.offset);
            }
        }
        g_asm_on_count = 0;
        for (size_t i = 0; i < set.count; i++) {
            AsmOn &a = g_asm_on[g_asm_on_count];
            if (set.entries[i].enabled && cvm::AsmOriginal(set.entries[i].definition, a.offset, a.original)) {
                std::memcpy(a.name, set.entries[i].definition.readable_name, sizeof(a.name));
                g_asm_on_count++;
            }
        }
        CodePatchesOff(set);
        SplitCheats(set);

        for (size_t i = 0; i < cvm::MaxCheatCount; i++) {
            g_run[i] = set.entries[i];
            g_reordered[i] = i < set.count && set.entries[i].enabled &&
                             cvm::ToRunOrder(set.entries[i].definition, g_run[i].definition, HookIsCode);
        }
        size_t total = 0, on = 0;
        for (size_t i = 0; i < set.count; i++)
            if (g_run[i].enabled) {
                total += g_run[i].definition.num_opcodes;
                on++;
            }
        g_program_loaded = false;
        if (!g_load_error[0]) {
            if (total > ams::dmnt::cheat::impl::CheatVirtualMachine::MaximumProgramOpcodeCount)
                snprintf(g_load_error, sizeof(g_load_error), "the cheats that are on need %zu opcodes, the VM holds 1024 (dmnt would run none either)", total);
            else if (!g_vm.LoadProgram(g_run, set.count))
                snprintf(g_load_error, sizeof(g_load_error), "LoadProgram refused");
            else
                g_program_loaded = true;
        }
        cvm::Log("loaded %s: %zu entries, %zu on, %zu opcodes%s%s", g_cheat_path + 4, set.count ? set.count - 1 : 0, on, total,
                 g_load_error[0] ? " - " : "", g_load_error);
        WriteStatus();
#if CVM_UI
        ReadMenuConfig();
        PublishMenu(on, total);
#endif
    }

    void FillMetadata() {
        const auto &main = exl::util::GetMainModuleInfo();
        std::memset(&g_meta, 0, sizeof(g_meta));
        g_meta.main_nso_extents = {main.m_Total.m_Start, main.m_Total.m_Size};
        svcGetInfo(&g_meta.heap_extents.base, InfoType_HeapRegionAddress, CUR_PROCESS_HANDLE, 0);
        svcGetInfo(&g_meta.heap_extents.size, InfoType_HeapRegionSize, CUR_PROCESS_HANDLE, 0);
        svcGetInfo(&g_meta.alias_extents.base, InfoType_AliasRegionAddress, CUR_PROCESS_HANDLE, 0);
        svcGetInfo(&g_meta.alias_extents.size, InfoType_AliasRegionSize, CUR_PROCESS_HANDLE, 0);
        svcGetInfo(&g_meta.aslr_extents.base, InfoType_AslrRegionAddress, CUR_PROCESS_HANDLE, 0);
        svcGetInfo(&g_meta.aslr_extents.size, InfoType_AslrRegionSize, CUR_PROCESS_HANDLE, 0);
        svcGetInfo(&g_meta.program_id, InfoType_ProgramId, CUR_PROCESS_HANDLE, 0);
        MainBuildId(g_meta.main_nso_module_id);
    }

    alignas(0x1000) u8 g_stack[0x10000];
    nn::os::ThreadType g_thread;

    void VmThread(void *) {
        /* No file call before the game's own fs setup (SetAllocator aborts once fs has
           been used): wait until it reads the controller, or 10 s. */
        for (int i = 0; i < 100 && g_reads == 0; i++)
            nn::os::SleepThread(nn::TimeSpan::FromNanoSeconds(100000000));
        FillMetadata();
        if (R_FAILED(nn::fs::MountSdCardForDebug("cvm")))
            return;
        /* Every level: a fresh SD card or emulator sdmc folder may have no atmosphere/contents yet,
           and CreateDirectory makes one level only. */
        nn::fs::CreateDirectory("cvm:/atmosphere");
        nn::fs::CreateDirectory("cvm:/atmosphere/contents");
        snprintf(cvm::g_dir, sizeof(cvm::g_dir), "cvm:/atmosphere/contents/%016lX", g_meta.program_id);
        nn::fs::CreateDirectory(cvm::g_dir);
        std::strcat(cvm::g_dir, "/cheats");
        nn::fs::CreateDirectory(cvm::g_dir);
        std::strcat(cvm::g_dir, "/");
        cvm::StartLog();
        {
            const u8 *b = g_meta.main_nso_module_id;
            cvm::Log("cheatvm " CHEATVM_VERSION ": program %016lX build %02X%02X%02X%02X%02X%02X%02X%02X, main %lx+%lx", g_meta.program_id, b[0], b[1], b[2], b[3],
                     b[4], b[5], b[6], b[7], g_meta.main_nso_extents.base, g_meta.main_nso_extents.size);
        }
        u64 res_total = 0, res_used = 0;
        svcGetInfo(&res_total, InfoType_SystemResourceSizeTotal, CUR_PROCESS_HANDLE, 0);
        svcGetInfo(&res_used, InfoType_SystemResourceSizeUsed, CUR_PROCESS_HANDLE, 0);
        cvm::Log("system resource: %lx used of %lx (npdm system_resource_size)", res_used, res_total);

        cvm::ProbeCodePatching();
        FindCheatFile();
        for (u64 tick = 0;; tick++) {
            /* dmnt's rate: 12 passes a second; the files are looked at once a second. */
            if (tick % 12 == 0)
                ReloadIfChanged();
#if CVM_UI
            ApplyMenuRequests();
            cvm::menu::DrainNotes();
#endif
            if (g_program_loaded) {
                cvm::BeginPass();
                g_vm.Execute(&g_meta);
                cvm::EndPass();
            }
            if (tick % 120 == 60)
                WriteStatus();
            nn::os::SleepThread(nn::TimeSpan::FromNanoSeconds(1000000000 / 12));
        }
    }
}

/* The thread starts when the game's own code starts, after the SDK is up. */
HOOK_DEFINE_TRAMPOLINE(MainHook) {
    static void Callback() {
        if (R_SUCCEEDED(nn::os::CreateThread(&g_thread, VmThread, nullptr, g_stack, sizeof(g_stack), 16)))
            nn::os::StartThread(&g_thread);
        Orig();
    }
};

extern "C" void exl_main(void *x0, void *x1) {
    exl::hook::Initialize();
    MainHook::InstallAtFuncPtr(nnMain);
#if CVM_UI
    cvm::menu::Install();
#endif
    FullKeyOne::InstallAtFuncPtr(static_cast<void (*)(nn::hid::NpadFullKeyState *, const u32 &)>(nn::hid::GetNpadState));
    HandheldOne::InstallAtFuncPtr(static_cast<void (*)(nn::hid::NpadHandheldState *, const u32 &)>(nn::hid::GetNpadState));
    JoyDualOne::InstallAtFuncPtr(static_cast<void (*)(nn::hid::NpadJoyDualState *, const u32 &)>(nn::hid::GetNpadState));
    JoyLeftOne::InstallAtFuncPtr(static_cast<void (*)(nn::hid::NpadJoyLeftState *, const u32 &)>(nn::hid::GetNpadState));
    JoyRightOne::InstallAtFuncPtr(static_cast<void (*)(nn::hid::NpadJoyRightState *, const u32 &)>(nn::hid::GetNpadState));
    FullKeyMany::InstallAtFuncPtr(static_cast<int (*)(nn::hid::NpadFullKeyState *, int, const u32 &)>(nn::hid::GetNpadStates));
    HandheldMany::InstallAtFuncPtr(static_cast<int (*)(nn::hid::NpadHandheldState *, int, const u32 &)>(nn::hid::GetNpadStates));
    JoyDualMany::InstallAtFuncPtr(static_cast<int (*)(nn::hid::NpadJoyDualState *, int, const u32 &)>(nn::hid::GetNpadStates));
    JoyLeftMany::InstallAtFuncPtr(static_cast<int (*)(nn::hid::NpadJoyLeftState *, int, const u32 &)>(nn::hid::GetNpadStates));
    JoyRightMany::InstallAtFuncPtr(static_cast<int (*)(nn::hid::NpadJoyRightState *, int, const u32 &)>(nn::hid::GetNpadStates));
}

extern "C" NORETURN void exl_exception_entry() {
    EXL_ABORT("Default exception handler called!");
}
