/* What the VM thread (main.cpp) and the in-game menu (source/ui, UI build only) share. */
#pragma once
#include <cstddef>
#include <cstdint>

namespace cvm::menu {
    using u8 = std::uint8_t;
    using u16 = std::uint16_t;
    using u32 = std::uint32_t;
    using u64 = std::uint64_t;

    enum Kind : u8 {
        Cheat = 0,
        FolderOpen = 1,  /* 20000000 */
        FolderClose = 2, /* 20000001 */
    };

    struct Item {
        char name[0x40];
        u8 kind;
        bool on;
        u16 group; /* values of one mod share it (one on at a time); 0 for other cheats */
    };

    constexpr size_t MaxItems = 0x100;

    /* The cheat list as the VM thread last loaded it. */
    struct Snapshot {
        u32 generation;
        u32 count;
        Item items[MaxItems];
        char status[160];
        char game[64];  /* "program <TID>\nbuild <BID>", shown with or without cheats */
        char hint[256]; /* no cheat file: where to put it; empty otherwise */
    };

    /* cheatvm.ini: menu_keys, menu_font, menu_banner, menu_flip. */
    struct Config {
        u64 open_keys;
        bool system_font;
        bool banner;
        int flip; /* 0 auto, 1 flipped, -1 not flipped */
        int test_crop_w, test_crop_h; /* menu_test_crop = WxH: draw as if the game's crop were that (0: off) */
    };

    /* A cheat the menu turned on or off, by name (the list may have been reloaded since). */
    struct Request {
        char name[0x40];
        bool on;
    };

    /* VM thread. */
    void Publish(const Snapshot &s);
    size_t TakeRequests(Request *out, size_t max);
    void SetConfig(const Config &c);

    /* Menu. */
    void Read(Snapshot &out);
    void Ask(const char *name, bool on);
    Config GetConfig();
    bool IsOpen(); /* the game sees no buttons or sticks while it is */
    void SetOpen(bool open);

    /* NVN hooks; from exl_main, before the game starts. */
    void Install();

    /* Log lines from the render thread and the hooks, written by the VM thread (the only one
       that writes cheatvm_log.txt) when it calls DrainNotes. */
    void Note(const char *fmt, ...);
    void DrainNotes();

    /* "L+R+DDown" -> HidNpadButton bits; 0 when a name is not known. */
    u64 ParseKeys(const char *s);
}
