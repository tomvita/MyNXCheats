/* The menu's half of menu.hpp that is not drawing: the list, requests and settings the
   VM thread and the game's render thread pass each other. */
#if CVM_UI
#include "menu.hpp"
#include "lib.hpp"
#include "cvm.hpp"

#include <cstdarg>
#include <cstdio>

#include <cstring>
#include <strings.h>

namespace cvm::menu {
    namespace {
        /* Held for a copy at most; a yield when taken. */
        struct SpinLock {
            volatile int v = 0;
            void lock() {
                while (__atomic_exchange_n(&v, 1, __ATOMIC_ACQUIRE))
                    svcSleepThread(0);
            }
            void unlock() { __atomic_store_n(&v, 0, __ATOMIC_RELEASE); }
        };
        struct Guard {
            SpinLock &l;
            explicit Guard(SpinLock &l) : l(l) { l.lock(); }
            ~Guard() { l.unlock(); }
        };

        SpinLock g_lock;
        Snapshot g_snapshot;
        Request g_requests[64];
        size_t g_request_count = 0;
        Config g_config = {(1ull << 6) | (1ull << 7) | (1ull << 15), true, true, 0, 0, 0};
        volatile bool g_open = false;
    }

    void Publish(const Snapshot &s) {
        Guard g(g_lock);
        const u32 gen = g_snapshot.generation + 1;
        g_snapshot = s;
        g_snapshot.generation = gen;
    }

    void Read(Snapshot &out) {
        Guard g(g_lock);
        if (out.generation == g_snapshot.generation)
            return;
        out = g_snapshot;
    }

    size_t TakeRequests(Request *out, size_t max) {
        Guard g(g_lock);
        const size_t n = g_request_count < max ? g_request_count : max;
        std::memcpy(out, g_requests, n * sizeof(Request));
        std::memmove(g_requests, g_requests + n, (g_request_count - n) * sizeof(Request));
        g_request_count -= n;
        return n;
    }

    void Ask(const char *name, bool on) {
        Guard g(g_lock);
        if (g_request_count == sizeof(g_requests) / sizeof(g_requests[0]))
            return;
        Request &r = g_requests[g_request_count++];
        std::strncpy(r.name, name, sizeof(r.name) - 1);
        r.name[sizeof(r.name) - 1] = 0;
        r.on = on;
    }

    void SetConfig(const Config &c) {
        Guard g(g_lock);
        g_config = c;
    }

    Config GetConfig() {
        Guard g(g_lock);
        return g_config;
    }

    namespace {
        char g_notes[16][160];
        size_t g_note_count = 0;
        u32 g_notes_lost = 0;
    }

    void Note(const char *fmt, ...) {
        char line[160];
        va_list va;
        va_start(va, fmt);
        vsnprintf(line, sizeof(line), fmt, va);
        va_end(va);
        Guard g(g_lock);
        if (g_note_count == sizeof(g_notes) / sizeof(g_notes[0])) {
            g_notes_lost++;
            return;
        }
        std::memcpy(g_notes[g_note_count++], line, sizeof(line));
    }

    void DrainNotes() {
        char notes[16][160];
        size_t n;
        u32 lost;
        {
            Guard g(g_lock);
            n = g_note_count;
            std::memcpy(notes, g_notes, n * sizeof(notes[0]));
            g_note_count = 0;
            lost = g_notes_lost;
            g_notes_lost = 0;
        }
        for (size_t i = 0; i < n; i++)
            cvm::Log("menu: %s", notes[i]);
        if (lost)
            cvm::Log("menu: %u more lines lost", lost);
    }

    bool IsOpen() { return g_open; }
    void SetOpen(bool open) { g_open = open; }

    u64 ParseKeys(const char *s) {
        static const struct {
            const char *name;
            u64 bit;
        } names[] = {
            {"A", 1ull << 0},      {"B", 1ull << 1},      {"X", 1ull << 2},       {"Y", 1ull << 3},
            {"LS", 1ull << 4},     {"RS", 1ull << 5},     {"L", 1ull << 6},       {"R", 1ull << 7},
            {"ZL", 1ull << 8},     {"ZR", 1ull << 9},     {"PLUS", 1ull << 10},   {"MINUS", 1ull << 11},
            {"DLEFT", 1ull << 12}, {"DUP", 1ull << 13},   {"DRIGHT", 1ull << 14}, {"DDOWN", 1ull << 15},
            {"LEFT", 1ull << 12},  {"UP", 1ull << 13},    {"RIGHT", 1ull << 14},  {"DOWN", 1ull << 15},
        };
        u64 keys = 0;
        while (*s != 0) {
            while (*s == ' ' || *s == '+')
                s++;
            const char *e = s;
            while (*e != 0 && *e != ' ' && *e != '+' && *e != '\r' && *e != '\n')
                e++;
            if (e == s)
                break;
            u64 bit = 0;
            for (const auto &n : names)
                if (std::strlen(n.name) == (size_t)(e - s) && strncasecmp(n.name, s, e - s) == 0)
                    bit = n.bit;
            if (bit == 0)
                return 0;
            keys |= bit;
            s = e;
            if (*s == '\r' || *s == '\n')
                break;
        }
        return keys;
    }
}
#endif
