/* ImGui's sources, compiled once; a system header so its warnings don't stop -Werror. */
#pragma once
#pragma GCC system_header

#include "cvm_imgui.h"
#include "imgui.cpp"
#include "imgui_draw.cpp"
#include "imgui_tables.cpp"
#include "imgui_widgets.cpp"
