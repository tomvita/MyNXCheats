/* ImGui (ext/imgui, 1.91.9b) as the menu uses it: no files, no default allocator, no demo. */
#pragma once

#define IMGUI_DISABLE_FILE_FUNCTIONS
#define IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DISABLE_DEFAULT_SHELL_FUNCTIONS
#define IMGUI_DISABLE_DEFAULT_ALLOCATORS
#define IMGUI_DISABLE_WIN32_FUNCTIONS
#define IMGUI_DISABLE_OSX_FUNCTIONS
#define IMGUI_DISABLE_DEMO_WINDOWS
#define IMGUI_DISABLE_DEBUG_TOOLS
#define IMGUI_DISABLE_OBSOLETE_FUNCTIONS
#define IM_ASSERT(_EXPR) ((void)0)

#include "imgui.h"
