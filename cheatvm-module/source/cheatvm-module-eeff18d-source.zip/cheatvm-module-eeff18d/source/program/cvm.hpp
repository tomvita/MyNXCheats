/* What the VM thread (main.cpp) and the memory / keys backend (backend.cpp) share. */
#pragma once
#include <cstdint>

namespace cvm {
    using u32 = std::uint32_t;
    using u64 = std::uint64_t;

    /* Buttons as the game last read them (npad hooks in main.cpp). */
    u64 KeysHeld();
    /* The same, also while the in-game menu hides them from the game and the cheats. */
    u64 RawKeys();

    void Log(const char *fmt, ...);

    struct MemStats {
        u64 reads, read_faults;
        u64 writes, write_faults;
        u64 code_writes, code_unchanged;
        u64 vm_faults;
        u32 pause_requests;
        u64 code_refreshes, refresh_failures; /* RX -> R -> RX after a code write, see ProbeCodePatching */
    };
    extern MemStats g_mem;

    /* Patches a function of the module's own and calls it again. A real Switch, yuzu and Eden run
       the new instruction; a JIT that ignores ic ivau (ruzu, Oct 2026) runs the old one. Then every
       code write is followed by a permission change, which that JIT does act on. Logs the result. */
    void ProbeCodePatching();
    bool RefreshingCode();

    /* Readable / executable, as svcQueryMemory says now. */
    bool IsExecutable(u64 address);
}
