/* The VM's callbacks inside the game: memory, keys, and the files DebugLog writes. */
#include "lib.hpp"
#include "nn/fs.hpp"
#include "vm/stratosphere.hpp"
#include "vm/dmnt_cheat_api.hpp"
#include "cvm.hpp"

#include <new>

/* The probe: mov w0, #1; ret. ProbeCodePatching rewrites the mov. */
asm(R"(
    .pushsection .text
    .balign 16
    .global cvm_probe_fn
    .type cvm_probe_fn, %function
cvm_probe_fn:
    mov w0, #1
    ret
    .size cvm_probe_fn, . - cvm_probe_fn
    .popsection
)");
extern "C" u32 cvm_probe_fn();

namespace cvm {
    MemStats g_mem;
    bool g_refresh_code = false;

    namespace {
        struct Region {
            u64 base, size;
            u32 perm, type;
        };

        bool Query(u64 address, Region &r) {
            MemoryInfo mi;
            u32 page_info;
            if (R_FAILED(svcQueryMemory(&mi, &page_info, address)))
                return false;
            r = {mi.addr, mi.size, mi.perm, mi.type};
            return r.type != MemType_Unmapped;
        }

        /* A writable view of a read-only region (code, rodata), kept for the session:
           mapping it costs a few syscalls, and cheats rewrite the same hooks every pass. */
        constexpr int MaxAliases = 16;
        alignas(exl::util::RwPages) u8 g_alias_storage[MaxAliases][sizeof(exl::util::RwPages)];
        exl::util::RwPages *g_aliases[MaxAliases];
        int g_alias_count = 0;

        uintptr_t WritableView(const Region &r, u64 address) {
            for (int i = 0; i < g_alias_count; i++) {
                auto *p = g_aliases[i];
                if (address >= p->GetRo() && address < p->GetRo() + p->GetSize())
                    return p->GetRw() + (address - p->GetRo());
            }
            if (g_alias_count == MaxAliases)
                return 0;
            auto *p = new (g_alias_storage[g_alias_count]) exl::util::RwPages(r.base, r.size);
            g_aliases[g_alias_count++] = p;
            return p->GetRw() + (address - p->GetRo());
        }
    }

    bool IsExecutable(u64 address) {
        Region r;
        return Query(address, r) && (r.perm & Perm_X);
    }

    bool RefreshingCode() { return g_refresh_code; }

    /* Executable pages to R and back: an emulator whose JIT ignores ic ivau still drops its
       compiled blocks when a range becomes executable again. Never on a real Switch: a thread
       running the page while it is R would fault. */
    void RefreshCode(u64 address, size_t size) {
        const u64 start = address & ~u64(0xFFF);
        const u64 end = (address + size + 0xFFF) & ~u64(0xFFF);
        const Handle self = exl::util::proc_handle::Get();
        if (R_FAILED(svcSetProcessMemoryPermission(self, start, end - start, Perm_R)) ||
            R_FAILED(svcSetProcessMemoryPermission(self, start, end - start, Perm_Rx))) {
            g_mem.refresh_failures++;
            return;
        }
        g_mem.code_refreshes++;
    }

    /* The probe also runs on a thread pinned to another core. yuzu-family emulators keep a
       JIT per core, and an ic ivau drops blocks only in the JIT of the core that ran it: the
       VM thread sees its own patch while game threads on other cores keep the old code
       (Lichii: an ASM cheat turned on after the hooked code was compiled did nothing). */
    namespace {
        alignas(0x1000) u8 g_probe_stack[0x4000];
        u32 volatile g_probe_phase = 0, g_probe_first = 0, g_probe_second = 0;

        void ProbeThread(void *) {
            using Fn = u32 (*)();
            Fn volatile fn = cvm_probe_fn;
            g_probe_first = fn();
            g_probe_phase = 1;
            for (int i = 0; i < 2000 && g_probe_phase != 2; i++)
                svcSleepThread(1000000);
            g_probe_second = fn();
            g_probe_phase = 3;
            svcExitThread();
        }

        bool WaitPhase(u32 phase) {
            for (int i = 0; i < 2000 && g_probe_phase < phase; i++)
                svcSleepThread(1000000);
            return g_probe_phase >= phase;
        }

        /* Starts the other-core probe and waits for its first call; -1 when there is none. */
        int StartOtherCoreProbe(Handle &h) {
            u64 mask = 0;
            if (R_FAILED(svcGetInfo(&mask, InfoType_CoreMask, CUR_PROCESS_HANDLE, 0)))
                return -1;
            const int me = (int)svcGetCurrentProcessorNumber();
            int core = -1;
            for (int c = 0; c < 4 && core < 0; c++)
                if (c != me && (mask & (1ull << c)))
                    core = c;
            if (core < 0)
                return -1;
            u32 prio = 44;
            svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
            if (R_FAILED(svcCreateThread(&h, (void *)ProbeThread, nullptr,
                                         g_probe_stack + sizeof(g_probe_stack), (int)prio, core)))
                return -1;
            if (R_FAILED(svcStartThread(h)) || !WaitPhase(1)) {
                svcCloseHandle(h);
                return -1;
            }
            return core;
        }
    }

    void ProbeCodePatching() {
        using Fn = u32 (*)();
        Fn volatile fn = cvm_probe_fn;
        const u64 at = reinterpret_cast<u64>(cvm_probe_fn);
        const MemStats saved = g_mem;
        const u32 mov1 = 0x52800020, mov2 = 0x52800040; /* mov w0, #1 / #2 */
        const u32 first = fn();
        Handle other = 0;
        const int other_core = StartOtherCoreProbe(other);
        ams::dmnt::cheat::impl::WriteCheatProcessMemoryUnsafe(at, &mov2, 4);
        const u32 second = fn();
        u32 other_second = 2;
        if (other_core >= 0) {
            g_probe_phase = 2;
            WaitPhase(3);
            svcWaitSynchronizationSingle(other, 1000000000ull);
            svcCloseHandle(other);
            other_second = g_probe_phase == 3 ? g_probe_second : 0;
            Log("code patch test: core %d read %u before and %u after the patch (this thread on core %u)",
                other_core, g_probe_first, other_second, svcGetCurrentProcessorNumber());
        } else {
            Log("code patch test: no other core to run the probe on");
        }
        if (first != 1) {
            Log("code patch test: probe returned %u before the patch; nothing changed", first);
        } else if (second == 2 && other_second == 2) {
            Log("code patch test: the patched instruction runs (Switch, or an emulator that honours ic ivau)");
        } else if (second == 2) {
            g_refresh_code = true;
            Log("code patch test: ic ivau reached only this core's JIT (an emulator); code writes will refresh the page permission");
        } else {
            RefreshCode(at, 4);
            const u32 third = fn();
            if (third == 2) {
                g_refresh_code = true;
                Log("code patch test: stale instruction after ic ivau (an emulator JIT); code writes will refresh the page permission");
            } else {
                Log("code patch test: stale instruction after ic ivau, and a permission refresh did not help (got %u); ASM cheats may not take effect", third);
            }
        }
        ams::dmnt::cheat::impl::WriteCheatProcessMemoryUnsafe(at, &mov1, 4);
        g_mem = saved;
        g_mem.code_refreshes = 0;
        g_mem.refresh_failures = 0;
    }
}

namespace ams::dmnt::cheat::impl {
    using namespace cvm;

    Result ReadCheatProcessMemoryUnsafe(u64 address, void *out_data, size_t size) {
        g_mem.reads++;
        auto *dst = static_cast<u8 *>(out_data);
        while (size > 0) {
            Region r;
            if (!Query(address, r) || !(r.perm & Perm_R)) {
                /* dmnt's read fails here and the VM keeps its zero. */
                std::memset(dst, 0, size);
                g_mem.read_faults++;
                return 1;
            }
            const size_t n = std::min<u64>(size, r.base + r.size - address);
            std::memcpy(dst, reinterpret_cast<const void *>(address), n);
            address += n;
            dst += n;
            size -= n;
        }
        return 0;
    }

    Result WriteCheatProcessMemoryUnsafe(u64 address, const void *data, size_t size) {
        g_mem.writes++;
        auto *src = static_cast<const u8 *>(data);
        while (size > 0) {
            Region r;
            if (!Query(address, r) || !(r.perm & Perm_R)) {
                g_mem.write_faults++;
                return 1;
            }
            const size_t n = std::min<u64>(size, r.base + r.size - address);
            if (r.perm & Perm_W) {
                std::memcpy(reinterpret_cast<void *>(address), src, n);
            } else if (std::memcmp(reinterpret_cast<const void *>(address), src, n) == 0) {
                /* Hooks are rewritten every pass; leave a word that already holds the value. */
                g_mem.code_unchanged++;
            } else {
                const uintptr_t rw = WritableView(r, address);
                if (rw == 0) {
                    g_mem.write_faults++;
                    return 1;
                }
                std::memcpy(reinterpret_cast<void *>(rw), src, n);
                armDCacheFlush(reinterpret_cast<void *>(rw), n);
                armICacheInvalidate(reinterpret_cast<void *>(address), n);
                if (g_refresh_code && r.perm == Perm_Rx)
                    RefreshCode(address, n);
                g_mem.code_writes++;
            }
            address += n;
            src += n;
            size -= n;
        }
        return 0;
    }

    /* dmnt pauses the game around FF0/FF1. A thread inside the game cannot do that
       safely, so the opcodes are counted and otherwise ignored. */
    Result PauseCheatProcessUnsafe() {
        g_mem.pause_requests++;
        return 0;
    }

    Result ResumeCheatProcessUnsafe() {
        return 0;
    }
}

namespace ams::dmnt::cheat {
    void OnVmFault(Result rc) {
        cvm::g_mem.vm_faults++;
        cvm::Log("vm fault 0x%X (mismatched conditional?)", rc);
    }
}

namespace ams::hid {
    Result GetKeysHeld(u64 *out) {
        *out = cvm::KeysHeld();
        return 0;
    }
}

/* DebugLog (opcode FFF) writes sdmc:/atmosphere/cheat_vm_logs/<id>.log; the SD is mounted as cvm:. */
namespace ams::fs {
    namespace {
        void SdPath(const char *path, char (&out)[0x300]) {
            if (std::strncmp(path, "sdmc:", 5) == 0)
                util::SNPrintf(out, sizeof(out), "cvm:%s", path + 5);
            else
                util::SNPrintf(out, sizeof(out), "%s", path);
        }
        nn::fs::FileHandle Nn(FileHandle f) { return {reinterpret_cast<u64>(f.handle)}; }
    }

    Result EnsureDirectory(const char *path) {
        char p[0x300];
        SdPath(path, p);
        for (char *c = std::strchr(p, '/'); c != nullptr; c = std::strchr(c + 1, '/')) {
            *c = 0;
            if (c[-1] != ':')
                nn::fs::CreateDirectory(p);
            *c = '/';
        }
        nn::fs::CreateDirectory(p);
        return 0;
    }

    Result CreateFile(const char *path, s64 size) {
        char p[0x300];
        SdPath(path, p);
        return nn::fs::CreateFile(p, size);
    }

    Result OpenFile(FileHandle *out, const char *path, int mode) {
        char p[0x300];
        SdPath(path, p);
        nn::fs::FileHandle h;
        Result rc = nn::fs::OpenFile(&h, p, mode);
        if (R_FAILED(rc) && (mode & OpenMode_Write)) {
            nn::fs::CreateFile(p, 0);
            rc = nn::fs::OpenFile(&h, p, mode);
        }
        if (R_SUCCEEDED(rc))
            out->handle = reinterpret_cast<void *>(h._internal);
        return rc;
    }

    void CloseFile(FileHandle file) {
        nn::fs::CloseFile(Nn(file));
    }

    Result GetFileSize(s64 *out, FileHandle file) {
        return nn::fs::GetFileSize(reinterpret_cast<long *>(out), Nn(file));
    }

    Result WriteFile(FileHandle file, s64 offset, const void *buffer, size_t size, const WriteOption &option) {
        return nn::fs::WriteFile(Nn(file), offset, buffer, size, nn::fs::WriteOption::CreateOption(option.flags));
    }
}
