#include "cheats.hpp"

#include <cctype>
#include <strings.h>

namespace cvm {

    namespace {
        void SetError(CheatSet &set, const char *what, size_t at) {
            ams::util::SNPrintf(set.error, sizeof(set.error), "%s at byte %zu", what, at);
        }

        CheatEntry *ByName(CheatSet &set, const char *name) {
            for (size_t i = 0; i < set.count; i++)
                if (set.entries[i].definition.num_opcodes > 0 && std::strcmp(set.entries[i].definition.readable_name, name) == 0)
                    return &set.entries[i];
            return nullptr;
        }

        /* Name between s[i] (the opening bracket) and the closing one; returns the index after it, or 0. */
        size_t ReadName(const char *s, size_t len, size_t i, char close, char (&name)[0x40]) {
            size_t j = i + 1;
            while (j < len && s[j] != close)
                j++;
            if (j >= len)
                return 0;
            const size_t n = std::min(j - i - 1, sizeof(name) - 1);
            std::memcpy(name, s + i + 1, n);
            name[n] = 0;
            return j + 1;
        }

        constexpr u32 AsmNever = 0xC046F5F0u; /* if R15 != R15 */
        constexpr u32 CondEnd = 0x20000000u;

        /* A 4-byte static store, main relative, no offset register. The low byte holds address bits 32-39. */
        bool IsHookStore(const u32 *op) { return (op[0] & 0xFFFFFF00u) == 0x04000000u; }
        bool SameHook(const u32 *a, const u32 *b) { return a[0] == b[0] && a[1] == b[1]; }
        u64 HookOffset(const u32 *op) { return (static_cast<u64>(op[0] & 0xFF) << 32) | op[1]; }
    }

    bool ParseCheats(const char *s, size_t len, CheatSet &out, bool enabled_by_default) {
        std::memset(&out, 0, sizeof(out));
        out.count = 1; /* slot 0 is the master cheat's */
        CheatEntry *cur = nullptr;
        size_t i = 0;
        while (i < len) {
            const unsigned char c = static_cast<unsigned char>(s[i]);
            if (std::isspace(c)) {
                i++;
            } else if (c == '[') {
                if (out.count >= MaxCheatCount) {
                    SetError(out, "more than 255 cheats", i);
                    return false;
                }
                cur = &out.entries[out.count];
                cur->cheat_id = out.count++;
                if ((i = ReadName(s, len, i, ']', cur->definition.readable_name)) == 0) {
                    SetError(out, "unclosed [", len);
                    return false;
                }
            } else if (c == '{') {
                cur = &out.entries[0];
                if (cur->definition.num_opcodes > 0) {
                    SetError(out, "second master cheat", i);
                    return false;
                }
                if ((i = ReadName(s, len, i, '}', cur->definition.readable_name)) == 0) {
                    SetError(out, "unclosed {", len);
                    return false;
                }
            } else if (std::isxdigit(c)) {
                if (cur == nullptr) {
                    SetError(out, "code before any cheat name", i);
                    return false;
                }
                if (cur->definition.num_opcodes >= 0x100) {
                    SetError(out, "cheat over 256 opcodes", i);
                    return false;
                }
                for (size_t j = 1; j < 8; j++)
                    if (i + j >= len || !std::isxdigit(static_cast<unsigned char>(s[i + j]))) {
                        SetError(out, "opcode not 8 hex digits", i);
                        return false;
                    }
                char hex[9] = {};
                std::memcpy(hex, s + i, 8);
                cur->definition.opcodes[cur->definition.num_opcodes++] = static_cast<u32>(std::strtoul(hex, nullptr, 16));
                i += 8;
            } else {
                SetError(out, "unexpected character", i);
                return false;
            }
        }
        for (size_t k = 1; k < out.count; k++)
            out.entries[k].enabled = out.entries[k].definition.num_opcodes > 0 && enabled_by_default && !IsFolderMarker(out.entries[k].definition);
        out.entries[0].enabled = out.entries[0].definition.num_opcodes > 0;
        return true;
    }

    bool ParseToggles(const char *s, size_t len, CheatSet &set) {
        size_t i = 0;
        while (i < len) {
            if (std::isspace(static_cast<unsigned char>(s[i]))) {
                i++;
                continue;
            }
            if (s[i] != '[')
                return false;
            char name[0x40];
            if ((i = ReadName(s, len, i, ']', name)) == 0)
                return false;
            while (i < len && std::isspace(static_cast<unsigned char>(s[i])))
                i++;
            size_t j = i;
            while (j < len && !std::isspace(static_cast<unsigned char>(s[j])))
                j++;
            char toggle[8] = {};
            if (j - i >= sizeof(toggle))
                return false;
            std::memcpy(toggle, s + i, j - i);
            if (CheatEntry *e = ByName(set, name); e != nullptr && e->cheat_id != 0 && !IsFolderMarker(e->definition)) {
                if (!strcasecmp(toggle, "1") || !strcasecmp(toggle, "true") || !strcasecmp(toggle, "on"))
                    e->enabled = true;
                else if (!strcasecmp(toggle, "0") || !strcasecmp(toggle, "false") || !strcasecmp(toggle, "off"))
                    e->enabled = false;
            }
            i = j;
        }
        return true;
    }

    /* Same rules as Breeze's _asmToRunOrder (dmntcht.c). */
    bool ToRunOrder(const CheatDefinition &in, CheatDefinition &out, bool (*is_code)(u64 main_offset)) {
        const u32 *op = in.opcodes;
        const u32 n = in.num_opcodes;
        const u32 key = (n > 0 && (op[0] >> 28) == 0x8) ? 1 : 0;
        if (n > 0x100 - 2 || n < key * 2 + 6)
            return false;
        if (key && op[n - 1] != CondEnd)
            return false;
        const u32 *orig = op + key;
        const u32 *hook = op + key + 3;
        if (!IsHookStore(orig) || !SameHook(orig, hook))
            return false;

        /* The rest must be static stores and register loads, none of them to the hook. */
        const u32 body = key + 6;
        const u32 body_end = n - key;
        u32 i = body;
        while (i < body_end) {
            const u32 type = op[i] >> 28;
            u32 len;
            if (type == 0x0) {
                const u32 width = (op[i] >> 24) & 0xF;
                if (width != 1 && width != 2 && width != 4 && width != 8)
                    return false;
                len = (width == 8) ? 4 : 3;
                if (i + 1 < body_end && SameHook(op + i, orig))
                    return false;
            } else if (type == 0x4) {
                len = 3;
            } else {
                return false;
            }
            if (i + len > body_end)
                return false;
            i += len;
        }
        if (!is_code(HookOffset(orig)))
            return false;

        out = in;
        u32 *w = out.opcodes;
        u32 k = 0;
        if (key)
            w[k++] = op[0];
        w[k++] = AsmNever;
        std::memcpy(w + k, orig, 3 * sizeof(u32));
        k += 3;
        w[k++] = CondEnd;
        std::memcpy(w + k, op + body, (body_end - body) * sizeof(u32));
        k += body_end - body;
        std::memcpy(w + k, hook, 3 * sizeof(u32));
        k += 3;
        if (key)
            w[k++] = CondEnd;
        out.num_opcodes = k;
        return true;
    }

    bool AsmOriginal(const CheatDefinition &def, u64 &main_offset, u32 &original) {
        const u32 *op = def.opcodes;
        const u32 n = def.num_opcodes;
        const u32 key = (n > 0 && (op[0] >> 28) == 0x8) ? 1 : 0;
        if (n < key + 6 || !IsHookStore(op + key) || !SameHook(op + key, op + key + 3))
            return false;
        main_offset = HookOffset(op + key);
        original = op[key + 2];
        return true;
    }

    bool IsFolderMarker(const CheatDefinition &def) {
        if (def.num_opcodes == 0)
            return false;
        for (u32 i = 0; i < def.num_opcodes; i++)
            if ((def.opcodes[i] & ~1u) != CondEnd)
                return false;
        return true;
    }

    const char *LabelKey(const char *name) {
        const unsigned char *p = reinterpret_cast<const unsigned char *>(name);
        while (*p != 0 && (*p >= 0x80 || *p == ' '))
            p++;
        return reinterpret_cast<const char *>(p);
    }

    size_t TakeCaveFolder(CheatSet &set, CaveSet &caves) {
        caves.count = 0;
        size_t first = 0, last = 0;
        for (size_t i = 1; i < set.count && last == 0; i++) {
            const CheatDefinition &d = set.entries[i].definition;
            if (!IsFolderMarker(d))
                continue;
            if (first == 0 && !strcasecmp(LabelKey(d.readable_name), "code cave"))
                first = i;
            else if (first != 0 && !strcasecmp(LabelKey(d.readable_name), "code cave end"))
                last = i;
        }
        if (first == 0)
            return 0;
        if (last == 0)
            last = set.count - 1;
        for (size_t i = first + 1; i < last && caves.count < MaxCaveCount; i++)
            if (set.entries[i].definition.num_opcodes > 0)
                caves.defs[caves.count++] = set.entries[i].definition;
        const size_t moved = last - first + 1;
        for (size_t i = last + 1; i < set.count; i++) {
            set.entries[i - moved] = set.entries[i];
            set.entries[i - moved].cheat_id = i - moved;
        }
        for (size_t i = set.count - moved; i < set.count; i++)
            std::memset(&set.entries[i], 0, sizeof(set.entries[i]));
        set.count -= moved;
        return moved;
    }

    const CheatDefinition *FindCave(const CaveSet &caves, const char *name) {
        const char *key = LabelKey(name);
        for (size_t i = 0; i < caves.count; i++)
            if (std::strcmp(LabelKey(caves.defs[i].readable_name), key) == 0)
                return &caves.defs[i];
        return nullptr;
    }

    namespace {
        /* Words taken by the store at op, 0 when it is not a register-free type 0 store. */
        u32 StoreAt(const u32 *op, u32 left, Store &s) {
            if (left < 3 || (op[0] & 0xF00FFF00u) != 0)
                return 0;
            s.width = (op[0] >> 24) & 0xF;
            s.region = (op[0] >> 20) & 0xF;
            s.address = (static_cast<u64>(op[0] & 0xFF) << 32) | op[1];
            if (s.width == 8) {
                if (left < 4)
                    return 0;
                s.value = (static_cast<u64>(op[2]) << 32) | op[3];
                return 4;
            }
            if (s.width != 1 && s.width != 2 && s.width != 4)
                return 0;
            s.value = op[2];
            return 3;
        }
    }

    bool Stores(const CheatDefinition &def, Store *out, size_t max, size_t &count) {
        count = 0;
        for (u32 i = 0; i < def.num_opcodes;) {
            Store s;
            const u32 n = StoreAt(def.opcodes + i, def.num_opcodes - i, s);
            if (n == 0 || count >= max)
                return false;
            out[count++] = s;
            i += n;
        }
        return count > 0;
    }

    bool ParseSplitHook(const CheatDefinition &def, SplitHook &out) {
        out = SplitHook{};
        const u32 *op = def.opcodes;
        const u32 n = def.num_opcodes;
        const u32 at = (n > 0 && (op[0] >> 28) == 0x8) ? 1 : 0;
        if (n < at + 7 || (op[at] & 0xFFFFFF00u) != 0x14050000u)
            return false;
        out.cave = (static_cast<u64>(op[at] & 0xFF) << 32) | op[at + 1];
        out.first = op[at + 2];
        Store s;
        if (StoreAt(op + at + 3, n - at - 3, s) != 3 || s.region != 0 || s.width != 4)
            return false;
        out.hook = s.address;
        if (op[at + 6] == CondEnd)
            return n == at + 7 + at;
        /* The first form: 21000000 0400000H HHHHHHHH OOOOOOOO 20000000 */
        Store o;
        if (op[at + 6] != 0x21000000u || n < at + 11 || StoreAt(op + at + 7, n - at - 7, o) != 3 || o.address != out.hook)
            return false;
        out.original = static_cast<u32>(o.value);
        out.has_original = true;
        return true;
    }

    bool IsDefaultValue(const char *name) {
        const char *k = LabelKey(name);
        const size_t n = std::strlen(k);
        return n > 10 && std::strcmp(k + n - 10, " (default)") == 0;
    }

    bool ModOf(const char *name, char (&mod)[0x40]) {
        const char *k = LabelKey(name);
        size_t n = std::strlen(k);
        if (IsDefaultValue(name))
            n -= 10;
        const char *eq = nullptr;
        for (const char *p = k; p + 3 <= k + n; p++)
            if (std::memcmp(p, " = ", 3) == 0)
                eq = p;
        if (eq == nullptr || eq == k || eq + 3 >= k + n)
            return false;
        const size_t m = std::min(static_cast<size_t>(eq - k), sizeof(mod) - 1);
        std::memcpy(mod, k, m);
        mod[m] = 0;
        return true;
    }

    namespace {
        /* The folder marker set.entries[i] sits in directly, 0 at the top. */
        size_t FolderOf(const CheatSet &set, size_t i) {
            int depth = 0;
            for (size_t k = i; k-- > 1;) {
                const auto &d = set.entries[k].definition;
                if (!IsFolderMarker(d))
                    continue;
                if (d.opcodes[0] == 0x20000001u)
                    depth++;
                else if (depth-- == 0)
                    return k;
            }
            return 0;
        }

        bool StoresOnly(const CheatDefinition &def) {
            Store s[16];
            size_t n = 0;
            return def.num_opcodes > 0 && !IsFolderMarker(def) && Stores(def, s, 16, n) && n > 0;
        }

        /* Leading whole words a and b share (b may end there), as a length into a. */
        size_t SharedWords(const char *a, size_t an, const char *b, size_t bn) {
            size_t i = 0, words = 0;
            while (i < an && i < bn && a[i] == b[i]) {
                i++;
                if ((i == an || a[i] == ' ') && (i == bn || b[i] == ' '))
                    words = i;
            }
            return words;
        }
    }

    bool ModIn(const CheatSet &set, size_t i, char (&mod)[0x40]) {
        const char *name = set.entries[i].definition.readable_name;
        if (ModOf(name, mod))
            return true;
        if (!StoresOnly(set.entries[i].definition))
            return false;
        const char *k = LabelKey(name);
        const size_t kn = std::strlen(k) - (IsDefaultValue(name) ? 10 : 0);
        const size_t folder = FolderOf(set, i);
        /* The default of i's folder whose name shares words with i's; the group is every store-only
           cheat there sharing words with that default, and the mod what all of them share. */
        for (size_t d = folder + 1; d < set.count; d++) {
            const auto &dd = set.entries[d].definition;
            if (!IsDefaultValue(dd.readable_name) || FolderOf(set, d) != folder || !StoresOnly(dd) || ModOf(dd.readable_name, mod))
                continue;
            const char *dk = LabelKey(dd.readable_name);
            const size_t dn = std::strlen(dk) - 10;
            if (SharedWords(dk, dn, k, kn) == 0)
                continue;
            size_t common = dn;
            size_t members = 0;
            for (size_t j = folder + 1; j < set.count; j++) {
                const auto &dj = set.entries[j].definition;
                if (j == d || FolderOf(set, j) != folder || !StoresOnly(dj) || ModOf(dj.readable_name, mod))
                    continue;
                const char *jk = LabelKey(dj.readable_name);
                const size_t jn = std::strlen(jk) - (IsDefaultValue(dj.readable_name) ? 10 : 0);
                const size_t w = SharedWords(dk, dn, jk, jn);
                if (w == 0)
                    continue;
                members++;
                if (w < common)
                    common = w;
            }
            /* A value, not the whole name: "EXP x2" against "EXP x2 (default)" alone is no group. */
            if (members == 0 || common == 0 || common >= dn)
                return false;
            const size_t m = std::min(common, sizeof(mod) - 1);
            std::memcpy(mod, dk, m);
            mod[m] = 0;
            return true;
        }
        return false;
    }

    size_t ProgramSize(const CheatSet &set) {
        size_t total = 0;
        for (size_t i = 0; i < set.count; i++)
            if (set.entries[i].enabled)
                total += set.entries[i].definition.num_opcodes;
        return total;
    }
}
