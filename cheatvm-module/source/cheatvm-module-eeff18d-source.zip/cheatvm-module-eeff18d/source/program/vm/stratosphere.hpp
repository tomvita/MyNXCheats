/*
 * Stand-in for <stratosphere.hpp>, so dmnt.gen2's cheat VM (dmnt_cheat_vm.cpp/.hpp,
 * copied unchanged from Atmosphere 118c11f33) builds inside a game module, and on a PC
 * for tests. It provides only what the VM uses; vm_backend.hpp does the real work.
 */
#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <cstdarg>
#include <bit>
#include <memory>
#include <algorithm>
#include <cstdlib>

namespace ams {
    using u8 = std::uint8_t;
    using u16 = std::uint16_t;
    using u32 = std::uint32_t;
    using u64 = std::uint64_t;
    using s8 = std::int8_t;
    using s16 = std::int16_t;
    using s32 = std::int32_t;
    using s64 = std::int64_t;
    using Result = std::uint32_t;

    namespace util {
        inline int SNPrintf(char *dst, size_t size, const char *fmt, ...) {
            va_list va;
            va_start(va, fmt);
            const int n = std::vsnprintf(dst, size, fmt, va);
            va_end(va);
            return n;
        }
        inline int VSNPrintf(char *dst, size_t size, const char *fmt, va_list va) {
            return std::vsnprintf(dst, size, fmt, va);
        }
    }

    /* Only DebugLog (opcode FFF) and the compiled-out debug log use files. */
    namespace fs {
        constexpr size_t EntryNameLengthMax = 0x300;
        struct FileHandle { void *handle; };
        enum OpenMode { OpenMode_Read = 1, OpenMode_Write = 2, OpenMode_AllowAppend = 4 };
        struct WriteOption { int flags; static const WriteOption Flush; };
        inline const WriteOption WriteOption::Flush = {1};
        Result EnsureDirectory(const char *path);
        Result CreateFile(const char *path, s64 size);
        Result OpenFile(FileHandle *out, const char *path, int mode);
        void CloseFile(FileHandle file);
        Result GetFileSize(s64 *out, FileHandle file);
        Result WriteFile(FileHandle file, s64 offset, const void *buffer, size_t size, const WriteOption &option);
    }

    namespace hid {
        Result GetKeysHeld(u64 *out);
    }

    namespace dmnt::cheat {
        struct CheatProcessMetadata {
            struct MemoryRegionExtents {
                u64 base;
                u64 size;
            };
            u64 process_id;
            u64 program_id;
            MemoryRegionExtents main_nso_extents;
            MemoryRegionExtents heap_extents;
            MemoryRegionExtents alias_extents;
            MemoryRegionExtents aslr_extents;
            u8 main_nso_module_id[0x20];
        };
        struct CheatDefinition {
            char readable_name[0x40];
            uint32_t num_opcodes;
            uint32_t opcodes[0x100];
        };
        struct CheatEntry {
            bool enabled;
            uint32_t cheat_id;
            CheatDefinition definition;
        };
        constexpr Result ResultVirtualMachineInvalidConditionDepth() { return 0x1E6C7; }

        /* dmnt aborts itself on a VM fault; in a game that would take the game down,
           so the backend records it and the VM carries on as after the abort point. */
        void OnVmFault(Result rc);
    }
}

#ifndef R_FAILED
#define R_FAILED(rc) ((rc) != 0)
#endif
#ifndef R_SUCCEEDED
#define R_SUCCEEDED(rc) ((rc) == 0)
#endif
#undef R_ABORT_UNLESS
#define R_ABORT_UNLESS(expr) do { const ::ams::Result _rc = (expr); if (R_FAILED(_rc)) ::ams::dmnt::cheat::OnVmFault(_rc); } while (0)
#define AMS_UNUSED(...) ((void)(__VA_ARGS__))

namespace ams::impl {
    template<typename F> struct ScopeExit { F f; ~ScopeExit() { f(); } };
    struct ScopeExitMaker { template<typename F> ScopeExit<F> operator+(F &&f) { return {static_cast<F &&>(f)}; } };
}
#define AMS_CONCAT_(a, b) a##b
#define AMS_CONCAT(a, b) AMS_CONCAT_(a, b)
#define ON_SCOPE_EXIT auto AMS_CONCAT(scope_exit_, __LINE__) = ::ams::impl::ScopeExitMaker() + [&]()
