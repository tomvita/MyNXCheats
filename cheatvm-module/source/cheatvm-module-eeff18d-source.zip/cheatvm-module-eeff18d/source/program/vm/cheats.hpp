/* Cheat files the way dmnt reads them, plus Breeze's ASM run order. No platform code: tested on a PC too. */
#pragma once
#include "stratosphere.hpp"

namespace cvm {
    using ams::u32;
    using ams::u64;
    using ams::dmnt::cheat::CheatEntry;
    using ams::dmnt::cheat::CheatDefinition;

    /* Entry 0 is the master cheat ({name}), the rest are [name] cheats. dmnt holds 0x80;
       Breeze files with folders go past that (FFRS: 131), so this holds more. */
    constexpr size_t MaxCheatCount = 0x100;

    struct CheatSet {
        CheatEntry entries[MaxCheatCount];
        size_t count;      /* entries in use, the master slot included */
        char error[128];   /* why parsing stopped, "" when it did not */
    };

    /* dmnt's ParseCheats: [name] / {name} / 8-digit hex opcodes, whitespace between.
       Cheats start enabled_by_default; a master cheat is always on; Breeze folder
       markers (IsFolderMarker) are never on. */
    bool ParseCheats(const char *s, size_t len, CheatSet &out, bool enabled_by_default);

    /* dmnt's ParseCheatToggles: "[name] on|off|true|false|1|0", names not in the set ignored. */
    bool ParseToggles(const char *s, size_t len, CheatSet &set);

    /* Breeze's ASM hook layout (orig store, branch store, cave stores) reordered so the
       cave is written before the branch and the original never runs (see Breeze
       dmntcht.c). is_code(main relative offset) says whether the hook is in code.
       Returns false, out untouched, for any cheat that must run as stored. */
    bool ToRunOrder(const CheatDefinition &in, CheatDefinition &out, bool (*is_code)(u64 main_offset));

    /* For a cheat in Breeze's ASM layout: the hook's main relative offset and its original
       instruction, written back when the cheat is switched off. */
    bool AsmOriginal(const CheatDefinition &def, u64 &main_offset, u32 &original);

    /* A Breeze folder line: nothing but 20000000 (folder start) / 20000001 (folder end). */
    bool IsFolderMarker(const CheatDefinition &def);

    /* Breeze's split ASM cheats (beta127): the [code cave] folder holds one cheat per cave,
       named like its hook cheat, plus "<name> (off)" with the store that puts the game's
       instruction back. They are written once, never run by the VM. */
    constexpr size_t MaxCaveCount = 0x80;
    struct CaveSet {
        CheatDefinition defs[MaxCaveCount];
        size_t count;
    };

    /* Moves the [code cave] .. [code cave end] folder out of set into caves, markers
       included; the remaining cheats keep their order. Returns the number moved. */
    size_t TakeCaveFolder(CheatSet &set, CaveSet &caves);

    /* A cheat name without leading key hint glyphs and spaces (Breeze's cave_label_key). */
    const char *LabelKey(const char *name);

    /* The cave cheat called name (compared by LabelKey), or nullptr. */
    const CheatDefinition *FindCave(const CaveSet &caves, const char *name);

    /* A split hook: 1405000H CCCCCCCC FFFFFFFF (cave filled?) 0400000H HHHHHHHH BBBBBBBB
       20000000, optionally inside a key; the first form adds 21000000 + the original store. */
    struct SplitHook {
        u64 cave;        /* main relative */
        u32 first;       /* the cave's first word when filled */
        u64 hook;        /* main relative */
        u32 original;
        bool has_original;
    };
    bool ParseSplitHook(const CheatDefinition &def, SplitHook &out);

    /* One 0TMR00AA AAAAAAAA value store with no register. */
    struct Store {
        u32 region; /* 0 main, 1 heap, ... */
        u64 address;
        u32 width;
        u64 value;
    };
    /* Every store of def into out (up to max); false when def holds anything else. */
    bool Stores(const CheatDefinition &def, Store *out, size_t max, size_t &count);

    /* "<mod> = <value>" or "<mod> = <value> (default)": the mod name into mod, else false. */
    bool ModOf(const char *name, char (&mod)[0x40]);
    /* The mod of set.entries[i]: ModOf, or a labelled value ("EXP x2", "One-hit kill on") -- a store-only
       cheat in the folder of a store-only "<...> (default)", the mod being the leading words they share. */
    bool ModIn(const CheatSet &set, size_t i, char (&mod)[0x40]);
    bool IsDefaultValue(const char *name);

    /* Opcodes the VM will run for the enabled cheats (dmnt's 0x400 total). */
    size_t ProgramSize(const CheatSet &set);
}
