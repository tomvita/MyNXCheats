/* Stand-in for dmnt's cheat API: what the VM calls back into. Implemented by the backend. */
#pragma once
#include "stratosphere.hpp"

namespace ams::dmnt::cheat::impl {
    Result ReadCheatProcessMemoryUnsafe(u64 address, void *out_data, size_t size);
    Result WriteCheatProcessMemoryUnsafe(u64 address, const void *data, size_t size);
    Result PauseCheatProcessUnsafe();
    Result ResumeCheatProcessUnsafe();
}
