# cheatvm-module

Atmosphère's cheat VM running **inside the game**, as an exefs `subsdk9` module
built on [exlaunch](https://github.com/shadowninja108/exlaunch). The module runs
the same cheat files as dmnt, Breeze and Eden, with the full Atmosphère opcode set.
That includes the extensions Eden's own VM lacks, and Breeze's split ASM cheats
(the `[code cave]` folder).

It was written for Eden, whose built-in VM is incomplete, and is tested on a real
Switch too. Final Fantasy Resonance (0100606026F12000, build 84E182F72EE1DA4F)
is the test game.

There are two builds from the same source:

| Build | Command | Output | What it adds |
|---|---|---|---|
| plain | `make` | `deploy/subsdk9` (~85 KB) | the VM only |
| menu | `make UI=1` | `deploy-ui/subsdk9` (~370 KB) | an in-game ImGui cheat menu drawn over the game's frame |

Keep both builds around: if something goes wrong with the menu build, the plain
one tells a VM problem from a menu problem.

## Installing

`subsdk9` does not depend on the game: the same file works for every title.

### Eden

Copy into Eden's user folder (File > Open Eden Folder):

```
load/<TID>/cheatvm/exefs/subsdk9                            the module
sdmc/atmosphere/contents/<TID>/cheats/<BID>.txt              cheat file
sdmc/atmosphere/contents/<TID>/cheats/cheatvm_toggles.txt    on/off list (optional)
```

- **No `main.npdm`.** The game keeps its own; Eden never checks syscall permissions.
- **"cheatvm" appears in the game's Add-ons list.** Leave it ticked.
- **Never put the cheat file under `load/`.** Eden would run it with its own VM as well.

### Lichii

Same layout as Eden, in Lichii's data folder. Find it with **File > Open Lichii
Folders > Root Data Folder**; don't guess:

- **Portable:** if a folder named `user` sits next to `lichii.exe`, that folder is the
  data folder.
- **Otherwise:** `%APPDATA%\lichii`. Builds before upstream 290da9e8 used
  `%APPDATA%\eden`, so after an update the files may be in the other folder. A
  `user\load\...` folder you create next to the exe is not read while Lichii uses
  AppData.
- **The settings can move `load/` and the SD card folder elsewhere.** File > Open
  Lichii Folders > Mod Folder and SDMC Folder open the ones in use.

"cheatvm" in the game's Add-ons list means the module was found.

### Extracted games (Eden and Lichii)

A game kept as a folder (`main`, `main.npdm`, `rtld`, `sdk`, ...) and opened by its
`main` skips `load/`, so `load/<TID>/cheatvm/` has no effect. Put `subsdk9` straight
into the game's own exefs folder, next to `main`:

- **Check first that the game has no `subsdk9` of its own.** Most games stop at
  `subsdk0`-`subsdk2`.
- **Back up the folder.** To undo, delete the file.
- **The cheat file and `cheatvm_toggles.txt` stay under `sdmc/`** as above.

### ASM cheats turned on mid-game on an emulator

Lichii and other yuzu-family emulators keep a JIT per CPU core, and an `ic ivau`
reaches only the core that ran it. The start-up code patch test therefore runs on
two cores. When only one sees the patch, code writes refresh the page permission
instead (`code page refreshes` in `cheatvm_status.txt`). Verified on Lichii with OoT.

### Switch (Atmosphère)

```
atmosphere/contents/<TID>/exefs/subsdk9
atmosphere/contents/<TID>/exefs/main.npdm     required, see below
atmosphere/contents/<TID>/cheats/<BID>.txt
```

On the Switch the npdm matters:
- **The game's own npdm will not work.** Retail npdms deny the syscalls exlaunch
  needs (0x73-0x78), and hook setup crashes. Without a `main.npdm` in exefs, the
  game falls back to its own.
- **The build's npdm is made from `config.json`.** Set the program id, main thread
  stack size, process flags and `system_resource_size` to the target game's values.
- **`system_resource_size` must not be 0** for games that map physical memory
  (FFRS maps 1.7 GB in the alias region). With 0, the game quits silently, with no
  crash report. FFRS uses 64 MB (`0x4000000`).

To undo: delete the `exefs` folder.

dmnt also reads `toggles.txt` and the same cheat file, and runs that file itself.
The module therefore keeps its own `cheatvm_toggles.txt`: dmnt rewrites
`toggles.txt` from its own state when the game exits.

## Files

All of these live in `atmosphere/contents/<TID>/cheats/` (under `sdmc/` on Eden and Lichii):

| File | Written by | What it is |
|---|---|---|
| `<BID>.txt` | you | the cheat file, dmnt format; Breeze folder markers and split cheats are understood |
| `cheatvm_toggles.txt` | you / the menu | `[cheat name]` then `on`/`off` (or `true`/`false`); copied from `toggles.txt` on the first run, otherwise a template listing every cheat as off |
| `cheatvm.ini` | you | optional settings, below |
| `cheatvm_log.txt` | the module | start-up, loads, cave fills, menu notes, faults |
| `cheatvm_status.txt` | the module | what is running now |

Edits to the cheat file, toggles and ini take effect within about a second, with no
restart. The menu build saves `cheatvm_toggles.txt` on every change it makes,
not when the game quits. The plain build only ever writes the template.

### cheatvm.ini

```
enabled_by_default = 0      1: [name] cheats start on, as with dmnt (default 0:
                            Breeze files keep "off" variants beside the cheats they undo)
menu_keys = L+R+DDown       menu build: the chord that opens and closes the menu, from
                            A B X Y L R ZL ZR PLUS MINUS LS RS DUP DDOWN DLEFT DRIGHT
menu_font = system          system (the console's shared fonts, every language) or builtin
menu_banner = 1             0: no "menu is here" banner
menu_flip = auto            1 if a game shows the menu upside down
menu_test_crop = 1280x720   test only: draw as if the game drew that much of its window (handheld)
```

## What the VM does beyond dmnt

- **Split ASM cheats (Breeze beta127+).** The `[code cave]` folder stays out of the VM.
  - When a hook turns on, its cave is filled.
  - When it turns off, the original instruction (or `<name> (off)`) is written back.
  - Code words are written through exlaunch's RW mapping, with a cache flush.
- **Mods** (several values of one setting) work one at a time:
  - `<mod> = <value>` cheats form a group;
  - so do labelled ones ("EXP x2" next to "EXP x1 (default)"): store-only cheats in
    the folder of a store-only `(default)` cheat, sharing its leading words.
  - When the last value of a group goes off, the `(default)` value is written back.
  - Only one at a time is enforced for changes from the menu; a hand-edited toggles
    file can still turn on two.
- **Keys** come from hooks on the game's own `GetNpadState(s)` calls. Calling hid
  directly for a controller style the game did not enable aborts the game.
- **Memory** reads and writes are checked with `svcQueryMemory`, so a bad pointer
  is counted as a fault instead of crashing.
- **Limits:** up to 255 cheats, and dmnt's 0x400 opcode budget for the enabled ones.
- **Emulators whose JIT ignores `ic ivau`** (ruzu, Oct 2026) would keep running the old code after a
  patch. At start the module patches a function of its own and calls it again (`code patch test` in the
  log). If the old instruction still runs, every code write is followed by an RX -> R -> RX permission
  change, which makes such a JIT drop the page. On a real Switch the test passes and this never happens:
  a thread running that page while it is R would fault.

## The menu (UI build)

- **Opening:** hold L+R and press Down. A turns a cheat on or off, or opens a folder.
  B goes back, and closes the menu at the top. Left/Right page through long lists.
- **Folders:** shown one level at a time, as Breeze shows them. A folder line shows how
  many cheats inside it are on.
- **While it is open:** the game gets no buttons, and its sticks read centred. Key
  cheats see no keys. Buttons go back to the game once all of them are released.
- **Banner:** shows for 10 s from the first button press after the cheats load.

How it draws:
- **Hooks:** `nvnBootstrapLoader` is found with `nn::ro::LookupSymbol`, which is the
  only new import, so a game without NVN still loads.
- **What it records from the game's NVN calls:** the device, the window textures,
  the origin mode, and the game's texture and sampler pools.
- **Drawing:** in `nvnQueuePresentTexture`, with its **own** command buffer, memory
  pools, shader, and texture and sampler pools, all in the module's `.bss`.
  - The game's pools are bound back afterwards.
  - It never borrows the game's command buffer: SMO-Exlaunch-Base does, which is
    unsafe in an Unreal game.
- **Fonts:** the console's shared fonts (`nn::pl`), with only the glyphs the cheat
  names use. ImGui is told it owns the font data; otherwise it copies each TTF, and
  the Chinese one does not fit in the 6 MB ImGui heap.

## Building

devkitPro (devkitA64, libnx tools) and Python 3. msys2's make ignores exported
environment variables, so pass them on the command line:

```
make DEVKITPRO=/c/devkitPro PATH=/c/devkitPro/devkitA64/bin:/c/devkitPro/tools/bin:<python>:/usr/bin:/bin
make UI=1 DEVKITPRO=... PATH=...
```

- **The ELF:** both builds write `cheatvm-module.elf` at the top. Copy it after each
  build if you need to symbolize crash offsets
  (`aarch64-none-elf-addr2line -f -C -i -e cheatvm-module.elf <offset>`).
- **Program id:** `PROGRAM_ID` in `config.mk` only picks the deploy folder. The
  module itself does not use it.
- **UI code** sits behind `#if CVM_UI`, because exlaunch's make rules compile every
  directory under `source/`.

## Layout

```
source/program/main.cpp       module entry, npad hooks, files, VM thread, reload, split caves, mods
source/program/backend.cpp    memory access for the VM (svcQueryMemory checks, RW aliases, cache flush)
source/program/vm/            dmnt.gen2's dmnt_cheat_vm.cpp/.hpp, unchanged, behind stand-in headers
                              (stratosphere.hpp, dmnt_cheat_api.hpp); cheats.cpp parses cheat files
source/program/menu.hpp       what the VM thread and the menu share (snapshot, requests, config)
source/ui/                    UI build only: ui.cpp (NVN hooks, drawing, menu), menu_state.cpp,
                              nvn/nvn.h, imgui_shader.inc
ext/imgui/                    Dear ImGui 1.91.9b
misc/                         exlaunch link script, specs, make rules
config.json                   the npdm for the Switch
```

## Traps found on the way

These are each worth one launch:
- **Module header:** newer rtld reads the module header as the classic one only
  if word 0 is 0 or `b +8`. `crt0.s` uses `b 1f; .word mod0; 1: b entrypoint`.
- **fs too early:** any `nn::fs` call before the game's own fs setup makes the
  game abort later (2002-6459). The SD card is mounted after the first hooked npad
  read, or after 10 s.
- **Origin mode:** FFRS (UE4) sets upper-left origin, yet a y-flipped projection
  came out upside down. Auto never flips.

## Credit and licences

- [exlaunch](https://github.com/shadowninja108/exlaunch) by shadowninja108: the
  base of this project (GPLv2, `LICENSE`). It includes
  [oss-rtld](https://github.com/shadowninja108/exlaunch/blob/main/source/lib/reloc/rtld/LICENSE.txt).
- [Atmosphère](https://github.com/Atmosphere-NX/Atmosphere): the cheat VM, via the
  dmnt.gen2 fork (GPLv2).
- [Dear ImGui](https://github.com/ocornut/imgui) by Omar Cornut (MIT, `ext/imgui/LICENSE.txt`).
- [SMO-Exlaunch-Base](https://github.com/CraftyBoss/SMO-Exlaunch-Base) (GPLv2): the
  precompiled ImGui shader, and `nvn.h` (MIT, h1k421).
