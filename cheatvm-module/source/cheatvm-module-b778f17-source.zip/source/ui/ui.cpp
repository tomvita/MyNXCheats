/*
 * The in-game menu (UI build only): ImGui drawn into the game's own frame.
 *
 * nvnBootstrapLoader is hooked, so every NVN function the game asks for passes through
 * Wrap: the device, the window textures, the window origin mode and the texture and
 * sampler pools the game binds are noted, and nvnQueuePresentTexture comes here first.
 * The menu is drawn just before the game's present, into the texture being presented,
 * with its own command buffer, memory pools, shader and texture / sampler pools; the
 * game's pools are bound back afterwards. Nothing is drawn, and the game's frame is left
 * as it is, while the menu is closed and the start banner has gone.
 *
 * Memory: everything (ImGui's heap and the GPU pools) is this module's own .bss, never
 * the game's allocator.
 */
#if CVM_UI
#include "lib.hpp"
#include "menu.hpp"
#include "cvm.hpp"
#include "vm/cheats.hpp"
#include "nvn/nvn.h"
#include "cvm_imgui.h"
#include "imgui_shader.inc"

#include <cfloat>
#include <cstdio>
#include <cstring>

namespace nn::ro {
    Result LookupSymbol(uintptr_t *out, const char *name);
}

namespace {
    using cvm::menu::Item;
    using cvm::menu::Snapshot;

    /* ---- ImGui's heap: first fit over a fixed arena, render thread only. ---- */

    alignas(16) u8 g_arena[6 << 20];
    struct FreeBlock {
        size_t size; /* the whole block, header included; kept while allocated */
        FreeBlock *next;
    };
    constexpr size_t BlockHeader = 16;
    FreeBlock *g_free = nullptr;
    bool g_arena_ready = false;
    u32 g_alloc_failures = 0;

    void *Alloc(size_t n, void *) {
        if (!g_arena_ready) {
            g_free = reinterpret_cast<FreeBlock *>(g_arena);
            g_free->size = sizeof(g_arena);
            g_free->next = nullptr;
            g_arena_ready = true;
        }
        const size_t need = (n + BlockHeader + 15) & ~size_t(15);
        for (FreeBlock **pp = &g_free; *pp != nullptr; pp = &(*pp)->next) {
            FreeBlock *b = *pp;
            if (b->size < need)
                continue;
            if (b->size - need >= 64) {
                FreeBlock *rest = reinterpret_cast<FreeBlock *>(reinterpret_cast<u8 *>(b) + need);
                rest->size = b->size - need;
                rest->next = b->next;
                *pp = rest;
                b->size = need;
            } else {
                *pp = b->next;
            }
            return reinterpret_cast<u8 *>(b) + BlockHeader;
        }
        g_alloc_failures++;
        return nullptr;
    }

    /* Not ours (the shared fonts ImGui is told it owns, so it does not copy them): left alone. */
    void Free(void *p, void *) {
        if (p < g_arena + BlockHeader || p >= g_arena + sizeof(g_arena))
            return;
        FreeBlock *b = reinterpret_cast<FreeBlock *>(static_cast<u8 *>(p) - BlockHeader);
        FreeBlock *prev = nullptr;
        FreeBlock *next = g_free;
        while (next != nullptr && next < b) {
            prev = next;
            next = next->next;
        }
        b->next = next;
        if (next != nullptr && reinterpret_cast<u8 *>(b) + b->size == reinterpret_cast<u8 *>(next)) {
            b->size += next->size;
            b->next = next->next;
        }
        if (prev == nullptr) {
            g_free = b;
        } else if (reinterpret_cast<u8 *>(prev) + prev->size == reinterpret_cast<u8 *>(b)) {
            prev->size += b->size;
            prev->next = b->next;
        } else {
            prev->next = b;
        }
    }

    /* ---- What the game's NVN calls tell us. ---- */

    PFNNVNDEVICEGETPROCADDRESSPROC g_get_proc;
    PFNNVNDEVICEINITIALIZEPROC g_device_init;
    PFNNVNQUEUEPRESENTTEXTUREPROC g_present;
    PFNNVNWINDOWBUILDERSETTEXTURESPROC g_builder_set_textures;
    PFNNVNWINDOWINITIALIZEPROC g_window_init;
    PFNNVNDEVICESETWINDOWORIGINMODEPROC g_set_origin_mode;
    PFNNVNCOMMANDBUFFERSETTEXTUREPOOLPROC g_set_texture_pool;
    PFNNVNCOMMANDBUFFERSETSAMPLERPOOLPROC g_set_sampler_pool;

    NVNdevice *g_device = nullptr;
    u32 g_devices = 0;
    int g_origin_mode = NVN_WINDOW_ORIGIN_MODE_LOWER_LEFT;
    const NVNtexturePool *volatile g_game_texture_pool = nullptr;
    const NVNsamplerPool *volatile g_game_sampler_pool = nullptr;

    struct Textures {
        const void *owner; /* builder, then window */
        int count;
        const NVNtexture *tex[8];
    };
    Textures g_builders[4];
    Textures g_windows[4];

    void Remember(Textures (&list)[4], const void *owner, int count, const NVNtexture *const *tex) {
        Textures *slot = nullptr;
        for (auto &t : list)
            if (t.owner == owner || (slot == nullptr && t.owner == nullptr))
                slot = &t;
        if (slot == nullptr)
            slot = &list[0];
        slot->owner = owner;
        slot->count = count < 8 ? count : 8;
        for (int i = 0; i < slot->count; i++)
            slot->tex[i] = tex[i];
    }

    const Textures *Find(const Textures (&list)[4], const void *owner) {
        for (const auto &t : list)
            if (t.owner == owner)
                return &t;
        return nullptr;
    }

    NVNboolean DeviceInit(NVNdevice *device, const NVNdeviceBuilder *builder) {
        const NVNboolean ok = g_device_init(device, builder);
        if (ok) {
            if (g_device == nullptr)
                g_device = device;
            g_devices++;
        }
        return ok;
    }

    void BuilderSetTextures(NVNwindowBuilder *builder, int count, NVNtexture *const *textures) {
        Remember(g_builders, builder, count, textures);
        g_builder_set_textures(builder, count, textures);
    }

    NVNboolean WindowInit(NVNwindow *window, const NVNwindowBuilder *builder) {
        const NVNboolean ok = g_window_init(window, builder);
        if (ok)
            if (const Textures *t = Find(g_builders, builder))
                Remember(g_windows, window, t->count, t->tex);
        return ok;
    }

    void SetOriginMode(NVNdevice *device, NVNwindowOriginMode mode) {
        g_origin_mode = mode;
        g_set_origin_mode(device, mode);
    }

    void SetTexturePool(NVNcommandBuffer *cmd, const NVNtexturePool *pool) {
        g_game_texture_pool = pool;
        g_set_texture_pool(cmd, pool);
    }

    void SetSamplerPool(NVNcommandBuffer *cmd, const NVNsamplerPool *pool) {
        g_game_sampler_pool = pool;
        g_set_sampler_pool(cmd, pool);
    }

    void Present(NVNqueue *queue, NVNwindow *window, int index);
    PFNNVNGENERICFUNCPTRPROC GetProc(const NVNdevice *device, const char *name);

    /* The game's own function, or ours in front of it. */
    PFNNVNGENERICFUNCPTRPROC Wrap(const char *name, PFNNVNGENERICFUNCPTRPROC p) {
        if (p == nullptr || name == nullptr)
            return p;
#define CVM_WRAP(fn, real, mine)                                     \
    if (std::strcmp(name, fn) == 0) {                                \
        real = reinterpret_cast<decltype(real)>(p);                  \
        return reinterpret_cast<PFNNVNGENERICFUNCPTRPROC>(&mine);    \
    }
        CVM_WRAP("nvnDeviceGetProcAddress", g_get_proc, GetProc)
        CVM_WRAP("nvnDeviceInitialize", g_device_init, DeviceInit)
        CVM_WRAP("nvnQueuePresentTexture", g_present, Present)
        CVM_WRAP("nvnWindowBuilderSetTextures", g_builder_set_textures, BuilderSetTextures)
        CVM_WRAP("nvnWindowInitialize", g_window_init, WindowInit)
        CVM_WRAP("nvnDeviceSetWindowOriginMode", g_set_origin_mode, SetOriginMode)
        CVM_WRAP("nvnCommandBufferSetTexturePool", g_set_texture_pool, SetTexturePool)
        CVM_WRAP("nvnCommandBufferSetSamplerPool", g_set_sampler_pool, SetSamplerPool)
#undef CVM_WRAP
        return p;
    }

    PFNNVNGENERICFUNCPTRPROC GetProc(const NVNdevice *device, const char *name) {
        return Wrap(name, g_get_proc(device, name));
    }

    /* ---- The NVN functions the menu itself calls (the game's, never our wrappers). ---- */

#define CVM_NVN_PROCS(X)                                              \
    X(DEVICEGETINTEGER, DeviceGetInteger)                             \
    X(DEVICEGETTEXTUREHANDLE, DeviceGetTextureHandle)                 \
    X(QUEUESUBMITCOMMANDS, QueueSubmitCommands)                       \
    X(QUEUEFENCESYNC, QueueFenceSync)                                 \
    X(SYNCINITIALIZE, SyncInitialize)                                 \
    X(SYNCWAIT, SyncWait)                                             \
    X(WINDOWGETCROP, WindowGetCrop)                                   \
    X(COMMANDBUFFERINITIALIZE, CommandBufferInitialize)               \
    X(COMMANDBUFFERSETMEMORYCALLBACK, CommandBufferSetMemoryCallback) \
    X(COMMANDBUFFERADDCOMMANDMEMORY, CommandBufferAddCommandMemory)   \
    X(COMMANDBUFFERADDCONTROLMEMORY, CommandBufferAddControlMemory)   \
    X(COMMANDBUFFERBEGINRECORDING, CommandBufferBeginRecording)       \
    X(COMMANDBUFFERENDRECORDING, CommandBufferEndRecording)           \
    X(COMMANDBUFFERBINDPROGRAM, CommandBufferBindProgram)             \
    X(COMMANDBUFFERBINDUNIFORMBUFFER, CommandBufferBindUniformBuffer) \
    X(COMMANDBUFFERUPDATEUNIFORMBUFFER, CommandBufferUpdateUniformBuffer) \
    X(COMMANDBUFFERSETRENDERTARGETS, CommandBufferSetRenderTargets)   \
    X(COMMANDBUFFERSETVIEWPORT, CommandBufferSetViewport)             \
    X(COMMANDBUFFERSETSCISSOR, CommandBufferSetScissor)               \
    X(COMMANDBUFFERCLEARCOLOR, CommandBufferClearColor)               \
    X(COMMANDBUFFERCOPYBUFFERTOTEXTURE, CommandBufferCopyBufferToTexture) \
    X(COMMANDBUFFERBINDBLENDSTATE, CommandBufferBindBlendState)       \
    X(COMMANDBUFFERBINDCOLORSTATE, CommandBufferBindColorState)       \
    X(COMMANDBUFFERBINDCHANNELMASKSTATE, CommandBufferBindChannelMaskState) \
    X(COMMANDBUFFERBINDMULTISAMPLESTATE, CommandBufferBindMultisampleState) \
    X(COMMANDBUFFERBINDPOLYGONSTATE, CommandBufferBindPolygonState)   \
    X(COMMANDBUFFERBINDDEPTHSTENCILSTATE, CommandBufferBindDepthStencilState) \
    X(COMMANDBUFFERBINDVERTEXATTRIBSTATE, CommandBufferBindVertexAttribState) \
    X(COMMANDBUFFERBINDVERTEXSTREAMSTATE, CommandBufferBindVertexStreamState) \
    X(COMMANDBUFFERBINDVERTEXBUFFER, CommandBufferBindVertexBuffer)   \
    X(COMMANDBUFFERBINDTEXTURE, CommandBufferBindTexture)             \
    X(COMMANDBUFFERDRAWELEMENTSBASEVERTEX, CommandBufferDrawElementsBaseVertex) \
    X(COMMANDBUFFERSETTEXTUREPOOL, CommandBufferSetTexturePool)       \
    X(COMMANDBUFFERSETSAMPLERPOOL, CommandBufferSetSamplerPool)       \
    X(MEMORYPOOLBUILDERSETDEFAULTS, MemoryPoolBuilderSetDefaults)     \
    X(MEMORYPOOLBUILDERSETDEVICE, MemoryPoolBuilderSetDevice)         \
    X(MEMORYPOOLBUILDERSETFLAGS, MemoryPoolBuilderSetFlags)           \
    X(MEMORYPOOLBUILDERSETSTORAGE, MemoryPoolBuilderSetStorage)       \
    X(MEMORYPOOLINITIALIZE, MemoryPoolInitialize)                     \
    X(MEMORYPOOLGETBUFFERADDRESS, MemoryPoolGetBufferAddress)         \
    X(TEXTUREBUILDERSETDEFAULTS, TextureBuilderSetDefaults)           \
    X(TEXTUREBUILDERSETDEVICE, TextureBuilderSetDevice)               \
    X(TEXTUREBUILDERSETTARGET, TextureBuilderSetTarget)               \
    X(TEXTUREBUILDERSETFORMAT, TextureBuilderSetFormat)               \
    X(TEXTUREBUILDERSETSIZE2D, TextureBuilderSetSize2D)               \
    X(TEXTUREBUILDERSETSTORAGE, TextureBuilderSetStorage)             \
    X(TEXTUREBUILDERGETSTORAGESIZE, TextureBuilderGetStorageSize)     \
    X(TEXTUREINITIALIZE, TextureInitialize)                           \
    X(TEXTUREFINALIZE, TextureFinalize)                               \
    X(TEXTUREWRITETEXELS, TextureWriteTexels)                         \
    X(TEXTUREFLUSHTEXELS, TextureFlushTexels)                         \
    X(TEXTUREGETWIDTH, TextureGetWidth)                               \
    X(TEXTUREGETHEIGHT, TextureGetHeight)                             \
    X(TEXTUREGETFORMAT, TextureGetFormat)                             \
    X(SAMPLERBUILDERSETDEFAULTS, SamplerBuilderSetDefaults)           \
    X(SAMPLERBUILDERSETDEVICE, SamplerBuilderSetDevice)               \
    X(SAMPLERBUILDERSETMINMAGFILTER, SamplerBuilderSetMinMagFilter)   \
    X(SAMPLERBUILDERSETWRAPMODE, SamplerBuilderSetWrapMode)           \
    X(SAMPLERINITIALIZE, SamplerInitialize)                           \
    X(TEXTUREPOOLINITIALIZE, TexturePoolInitialize)                   \
    X(TEXTUREPOOLREGISTERTEXTURE, TexturePoolRegisterTexture)         \
    X(SAMPLERPOOLINITIALIZE, SamplerPoolInitialize)                   \
    X(SAMPLERPOOLREGISTERSAMPLER, SamplerPoolRegisterSampler)         \
    X(PROGRAMINITIALIZE, ProgramInitialize)                           \
    X(PROGRAMSETSHADERS, ProgramSetShaders)                           \
    X(BLENDSTATESETDEFAULTS, BlendStateSetDefaults)                   \
    X(BLENDSTATESETBLENDFUNC, BlendStateSetBlendFunc)                 \
    X(BLENDSTATESETBLENDEQUATION, BlendStateSetBlendEquation)         \
    X(COLORSTATESETDEFAULTS, ColorStateSetDefaults)                   \
    X(COLORSTATESETBLENDENABLE, ColorStateSetBlendEnable)             \
    X(CHANNELMASKSTATESETDEFAULTS, ChannelMaskStateSetDefaults)       \
    X(MULTISAMPLESTATESETDEFAULTS, MultisampleStateSetDefaults)       \
    X(POLYGONSTATESETDEFAULTS, PolygonStateSetDefaults)               \
    X(POLYGONSTATESETCULLFACE, PolygonStateSetCullFace)               \
    X(DEPTHSTENCILSTATESETDEFAULTS, DepthStencilStateSetDefaults)     \
    X(DEPTHSTENCILSTATESETDEPTHTESTENABLE, DepthStencilStateSetDepthTestEnable) \
    X(DEPTHSTENCILSTATESETDEPTHWRITEENABLE, DepthStencilStateSetDepthWriteEnable) \
    X(VERTEXATTRIBSTATESETDEFAULTS, VertexAttribStateSetDefaults)     \
    X(VERTEXATTRIBSTATESETFORMAT, VertexAttribStateSetFormat)         \
    X(VERTEXATTRIBSTATESETSTREAMINDEX, VertexAttribStateSetStreamIndex) \
    X(VERTEXSTREAMSTATESETDEFAULTS, VertexStreamStateSetDefaults)     \
    X(VERTEXSTREAMSTATESETSTRIDE, VertexStreamStateSetStride)

    struct Procs {
#define CVM_DECLARE(UPPER, Name) PFNNVN##UPPER##PROC Name;
        CVM_NVN_PROCS(CVM_DECLARE)
#undef CVM_DECLARE
    } nvn;

    bool LoadProcs() {
#define CVM_LOAD(UPPER, Name)                                                                   \
    nvn.Name = reinterpret_cast<PFNNVN##UPPER##PROC>(g_get_proc(g_device, "nvn" #Name));       \
    if (nvn.Name == nullptr) {                                                                  \
        cvm::menu::Note("nvn" #Name " not found, no menu");                                     \
        return false;                                                                           \
    }
        CVM_NVN_PROCS(CVM_LOAD)
#undef CVM_LOAD
        return true;
    }

    /* ---- The menu's GPU objects. ---- */

    constexpr size_t CommandSize = 0x80000;
    constexpr size_t ControlSize = 0x10000;
    constexpr size_t UboSize = 0x1000;
    constexpr size_t VertexSize = 0x100000;
    constexpr size_t IndexSize = 0x40000;
    constexpr size_t FontSize = 0x400000; /* 1024 x 1024 RGBA */
    constexpr int DescriptorCount = 300;
    constexpr int FontId = 280; /* the first 256 descriptors are the driver's */

    alignas(0x1000) u8 g_command_mem[CommandSize];
    alignas(0x1000) u8 g_control_mem[ControlSize];
    alignas(0x1000) u8 g_dynamic_mem[UboSize + VertexSize + IndexSize];
    alignas(0x1000) u8 g_shader_mem[0x4000];
    alignas(0x1000) u8 g_descriptor_mem[0x8000];
    alignas(0x1000) u8 g_font_mem[FontSize];

    NVNmemoryPool g_command_pool, g_dynamic_pool, g_shader_pool, g_descriptor_pool, g_font_pool;
    NVNcommandBuffer g_cmd;
    NVNsync g_sync;
    bool g_sync_pending = false;
    NVNprogram g_program;
    NVNtexturePool g_texture_pool;
    NVNsamplerPool g_sampler_pool;
    NVNtexture g_font_texture;
    bool g_font_texture_ok = false;
    NVNsampler g_font_sampler;
    NVNtextureHandle g_font_handle = 0;
    NVNbufferAddress g_dynamic_addr = 0;
    NVNblendState g_blend;
    NVNcolorState g_color;
    NVNchannelMaskState g_channel_mask;
    NVNmultisampleState g_multisample;
    NVNpolygonState g_polygon;
    NVNdepthStencilState g_depth_state;
    NVNvertexAttribState g_attribs[3];
    NVNvertexStreamState g_stream;
    bool g_out_of_memory = false;

    struct Ubo {
        float proj[4][4];
        int is_use_srgb; /* 1: write colours as they are; 0: convert them to linear first */
    };

    bool g_cpu_draw = false; /* the game refused the shader: ImGui is drawn by the CPU and copied (CpuRender) */
    const u8 *g_cpu_font = nullptr; /* the font atlas's alpha, for the CPU drawing */
    int g_cpu_font_w = 0, g_cpu_font_h = 0;
    u64 g_cpu_hash = 0; /* of the last panel drawn: an unchanged one is only copied again */

    enum class State { Waiting, Ready, Failed };
    State g_state = State::Waiting;

    void OutOfMemory(NVNcommandBuffer *, NVNcommandBufferMemoryEvent event, size_t, void *) {
        /* Only reachable if a frame needs more than CommandSize; that frame is broken. */
        g_out_of_memory = true;
        (void)event;
    }

    bool MakePool(NVNmemoryPool &pool, void *mem, size_t size, int flags) {
        NVNmemoryPoolBuilder b;
        nvn.MemoryPoolBuilderSetDefaults(&b);
        nvn.MemoryPoolBuilderSetDevice(&b, g_device);
        nvn.MemoryPoolBuilderSetFlags(&b, flags);
        nvn.MemoryPoolBuilderSetStorage(&b, mem, size);
        return nvn.MemoryPoolInitialize(&pool, &b);
    }

    bool InitGpu() {
        if (!LoadProcs())
            return false;
        const int data = NVN_MEMORY_POOL_FLAGS_CPU_UNCACHED | NVN_MEMORY_POOL_FLAGS_GPU_CACHED;
        if (!MakePool(g_command_pool, g_command_mem, CommandSize, data) ||
            !MakePool(g_dynamic_pool, g_dynamic_mem, sizeof(g_dynamic_mem), data) ||
            !MakePool(g_descriptor_pool, g_descriptor_mem, sizeof(g_descriptor_mem), data) ||
            !MakePool(g_font_pool, g_font_mem, FontSize, data)) {
            cvm::menu::Note("memory pool refused");
            return false;
        }
        std::memcpy(g_shader_mem, kImguiShader, sizeof(kImguiShader));
        if (!MakePool(g_shader_pool, g_shader_mem, sizeof(g_shader_mem), data | NVN_MEMORY_POOL_FLAGS_SHADER_CODE)) {
            cvm::menu::Note("shader memory pool refused");
            return false;
        }
        g_dynamic_addr = nvn.MemoryPoolGetBufferAddress(&g_dynamic_pool);

        if (!nvn.CommandBufferInitialize(&g_cmd, g_device) || !nvn.SyncInitialize(&g_sync, g_device)) {
            cvm::menu::Note("command buffer refused");
            return false;
        }
        nvn.CommandBufferSetMemoryCallback(&g_cmd, OutOfMemory);

        /* Two stages; the header holds both control offsets, then both data offsets. */
        u32 header[4];
        std::memcpy(header, g_shader_mem, sizeof(header));
        const NVNbufferAddress shader_addr = nvn.MemoryPoolGetBufferAddress(&g_shader_pool);
        NVNshaderData stages[2] = {
            {shader_addr + header[2], g_shader_mem + header[0]},
            {shader_addr + header[3], g_shader_mem + header[1]},
        };
        if (!nvn.ProgramInitialize(&g_program, g_device) || !nvn.ProgramSetShaders(&g_program, 2, stages)) {
            /* Switch 2 games (newer NVN, other GPU) refuse this Switch 1 shader binary: draw on the CPU and copy. */
            cvm::menu::Note("the shader was refused (NVN version?): the menu is drawn by the CPU");
            g_cpu_draw = true;
            return true;
        }

        int sampler_desc = 0, texture_desc = 0;
        nvn.DeviceGetInteger(g_device, NVN_DEVICE_INFO_SAMPLER_DESCRIPTOR_SIZE, &sampler_desc);
        nvn.DeviceGetInteger(g_device, NVN_DEVICE_INFO_TEXTURE_DESCRIPTOR_SIZE, &texture_desc);
        const size_t sampler_bytes = (size_t)sampler_desc * DescriptorCount;
        if (sampler_bytes + (size_t)texture_desc * DescriptorCount > sizeof(g_descriptor_mem) ||
            !nvn.SamplerPoolInitialize(&g_sampler_pool, &g_descriptor_pool, 0, DescriptorCount) ||
            !nvn.TexturePoolInitialize(&g_texture_pool, &g_descriptor_pool, sampler_bytes, DescriptorCount)) {
            cvm::menu::Note("texture / sampler pool refused (descriptor sizes %d %d)", texture_desc, sampler_desc);
            return false;
        }
        NVNsamplerBuilder sb;
        nvn.SamplerBuilderSetDefaults(&sb);
        nvn.SamplerBuilderSetDevice(&sb, g_device);
        nvn.SamplerBuilderSetMinMagFilter(&sb, NVN_MIN_FILTER_LINEAR, NVN_MAG_FILTER_LINEAR);
        nvn.SamplerBuilderSetWrapMode(&sb, NVN_WRAP_MODE_CLAMP, NVN_WRAP_MODE_CLAMP, NVN_WRAP_MODE_CLAMP);
        if (!nvn.SamplerInitialize(&g_font_sampler, &sb))
            return false;
        nvn.SamplerPoolRegisterSampler(&g_sampler_pool, FontId, &g_font_sampler);

        nvn.BlendStateSetDefaults(&g_blend);
        nvn.BlendStateSetBlendFunc(&g_blend, NVN_BLEND_FUNC_SRC_ALPHA, NVN_BLEND_FUNC_ONE_MINUS_SRC_ALPHA, NVN_BLEND_FUNC_ONE,
                                   NVN_BLEND_FUNC_ONE_MINUS_SRC_ALPHA);
        nvn.BlendStateSetBlendEquation(&g_blend, NVN_BLEND_EQUATION_ADD, NVN_BLEND_EQUATION_ADD);
        nvn.ColorStateSetDefaults(&g_color);
        nvn.ColorStateSetBlendEnable(&g_color, 0, true);
        nvn.ChannelMaskStateSetDefaults(&g_channel_mask);
        nvn.MultisampleStateSetDefaults(&g_multisample);
        nvn.PolygonStateSetDefaults(&g_polygon);
        nvn.PolygonStateSetCullFace(&g_polygon, NVN_FACE_NONE);
        nvn.DepthStencilStateSetDefaults(&g_depth_state);
        nvn.DepthStencilStateSetDepthTestEnable(&g_depth_state, false);
        nvn.DepthStencilStateSetDepthWriteEnable(&g_depth_state, false);
        const ptrdiff_t offsets[3] = {offsetof(ImDrawVert, pos), offsetof(ImDrawVert, uv), offsetof(ImDrawVert, col)};
        const NVNformat formats[3] = {NVN_FORMAT_RG32F, NVN_FORMAT_RG32F, NVN_FORMAT_RGBA8};
        for (int i = 0; i < 3; i++) {
            nvn.VertexAttribStateSetDefaults(&g_attribs[i]);
            nvn.VertexAttribStateSetFormat(&g_attribs[i], formats[i], offsets[i]);
            nvn.VertexAttribStateSetStreamIndex(&g_attribs[i], 0);
        }
        nvn.VertexStreamStateSetDefaults(&g_stream);
        nvn.VertexStreamStateSetStride(&g_stream, sizeof(ImDrawVert));
        return true;
    }

    void WaitGpu() {
        if (!g_sync_pending)
            return;
        const NVNsyncWaitResult r = nvn.SyncWait(&g_sync, 200000000);
        if (r == NVN_SYNC_WAIT_RESULT_TIMEOUT_EXPIRED || r == NVN_SYNC_WAIT_RESULT_FAILED)
            cvm::menu::Note("waited 200 ms for the last menu frame (result %d)", (int)r);
        g_sync_pending = false;
    }

    /* ---- Fonts: the console's shared fonts, only the glyphs the cheat names use. ---- */

    namespace pl {
        using RequestLoad = void (*)(int);
        using LoadState = int (*)(int);
        using Address = const void *(*)(int);
        using Size = size_t (*)(int);
        RequestLoad request_load;
        LoadState load_state;
        Address address;
        Size size;
        bool looked_up = false;

        bool LookUp() {
            if (!looked_up) {
                looked_up = true;
                uintptr_t p = 0;
                if (R_SUCCEEDED(nn::ro::LookupSymbol(&p, "_ZN2nn2pl21RequestSharedFontLoadENS0_14SharedFontTypeE")))
                    request_load = reinterpret_cast<RequestLoad>(p);
                if (R_SUCCEEDED(nn::ro::LookupSymbol(&p, "_ZN2nn2pl22GetSharedFontLoadStateENS0_14SharedFontTypeE")))
                    load_state = reinterpret_cast<LoadState>(p);
                if (R_SUCCEEDED(nn::ro::LookupSymbol(&p, "_ZN2nn2pl20GetSharedFontAddressENS0_14SharedFontTypeE")))
                    address = reinterpret_cast<Address>(p);
                if (R_SUCCEEDED(nn::ro::LookupSymbol(&p, "_ZN2nn2pl17GetSharedFontSizeENS0_14SharedFontTypeE")))
                    size = reinterpret_cast<Size>(p);
                if (!(request_load && load_state && address && size))
                    cvm::menu::Note("nn::pl shared font functions not found; built-in font");
            }
            return request_load && load_state && address && size;
        }
    }

    /* Standard, Chinese Simplified (+ext), Chinese Traditional, Korean, Nintendo extension. */
    constexpr int FontTypes[] = {0, 1, 2, 3, 4, 5};
    int g_font_px = 0;
    bool g_font_system = false;
    u64 g_font_glyph_hash = 0;
    int g_font_wait = 0;
    ImVector<ImWchar> g_glyph_ranges;
    ImFont *g_small_font = nullptr; /* the help line */

    Snapshot g_snap;

    const char *const UiText[] = {
        "Cheats", "cheatvm", "on", "off", "back", "close", "page", "A", "B", "no cheats", "(on)", "()", ">", "<",
        "0123456789", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", " +-=:/.,()[]{}!?%#&*'\"_",
    };

    u64 GlyphHash() {
        u64 h = 0xCBF29CE484222325ull;
        for (u32 i = 0; i < g_snap.count; i++)
            for (const char *s = g_snap.items[i].name; *s; s++)
                if ((u8)*s >= 0x80)
                    h = (h ^ (u8)*s) * 0x100000001B3ull;
        return h;
    }

    /* (Re)builds the atlas and its texture; the GPU must be done with the old one. */
    bool BuildFont(int px, bool system) {
        ImGuiIO &io = ImGui::GetIO();
        io.Fonts->Clear();
        g_glyph_ranges.clear();
        ImFontGlyphRangesBuilder rb;
        rb.AddRanges(io.Fonts->GetGlyphRangesDefault());
        for (const char *t : UiText)
            rb.AddText(t);
        for (u32 i = 0; i < g_snap.count; i++)
            rb.AddText(g_snap.items[i].name);
        rb.BuildRanges(&g_glyph_ranges);

        bool added = false;
        int first_type = -1;
        if (system) {
            for (size_t k = 0; k < sizeof(FontTypes) / sizeof(FontTypes[0]); k++) {
                const int type = FontTypes[k];
                if (pl::load_state(type) != 1)
                    continue;
                const void *data = pl::address(type);
                const size_t size = pl::size(type);
                if (data == nullptr || size == 0)
                    continue;
                ImFontConfig cfg;
                /* "Not owned" makes ImGui copy the whole TTF (the Chinese ones are megabytes); owned, it reads
                   the shared font in place, and Free ignores it. */
                cfg.FontDataOwnedByAtlas = true;
                cfg.MergeMode = added;
                cfg.OversampleH = 1;
                cfg.OversampleV = 1;
                cfg.PixelSnapH = true;
                std::snprintf(cfg.Name, sizeof(cfg.Name), "shared font %d", type);
                if (io.Fonts->AddFontFromMemoryTTF(const_cast<void *>(data), (int)size, (float)px, &cfg, g_glyph_ranges.Data)) {
                    if (!added)
                        first_type = type;
                    added = true;
                }
            }
        }
        const int small_px = px * 7 / 10;
        g_small_font = nullptr;
        if (!added) {
            ImFontConfig cfg;
            cfg.SizePixels = (float)(13 * (px / 13 > 0 ? px / 13 : 1));
            io.Fonts->AddFontDefault(&cfg);
            ImFontConfig small;
            small.SizePixels = (float)(13 * (small_px / 13 > 0 ? small_px / 13 : 1));
            g_small_font = io.Fonts->AddFontDefault(&small);
        } else {
            ImFontConfig cfg;
            cfg.FontDataOwnedByAtlas = true;
            cfg.OversampleH = 1;
            cfg.OversampleV = 1;
            cfg.PixelSnapH = true;
            std::snprintf(cfg.Name, sizeof(cfg.Name), "shared font %d small", first_type);
            g_small_font = io.Fonts->AddFontFromMemoryTTF(const_cast<void *>(pl::address(first_type)), (int)pl::size(first_type),
                                                          (float)small_px, &cfg, io.Fonts->GetGlyphRangesDefault());
        }
        io.Fonts->TexDesiredWidth = 1024;
        if (!io.Fonts->Build()) {
            cvm::menu::Note("font atlas did not build");
            return false;
        }
        unsigned char *pixels = nullptr;
        int w = 0, h = 0;
        if (g_cpu_draw) {
            /* The CPU samples the atlas itself: alpha only, kept in g_dynamic_mem (unused without the shader). */
            io.Fonts->GetTexDataAsAlpha8(&pixels, &w, &h);
            if ((size_t)w * h > sizeof(g_dynamic_mem)) {
                cvm::menu::Note("font atlas %dx%d does not fit the CPU copy", w, h);
                return false;
            }
            std::memcpy(g_dynamic_mem, pixels, (size_t)w * h);
            g_cpu_font = g_dynamic_mem;
            g_cpu_font_w = w;
            g_cpu_font_h = h;
            g_cpu_hash = 0;
            io.Fonts->SetTexID((ImTextureID)1);
            io.Fonts->ClearTexData();
            g_font_px = px;
            g_font_system = added;
            g_font_glyph_hash = GlyphHash();
            cvm::menu::Note("font: %s, %d px, atlas %dx%d (CPU)", added ? "shared system font" : "built-in", px, w, h);
            return true;
        }
        io.Fonts->GetTexDataAsRGBA32(&pixels, &w, &h);

        if (g_font_texture_ok) {
            nvn.TextureFinalize(&g_font_texture);
            g_font_texture_ok = false;
        }
        NVNtextureBuilder tb;
        nvn.TextureBuilderSetDefaults(&tb);
        nvn.TextureBuilderSetDevice(&tb, g_device);
        nvn.TextureBuilderSetTarget(&tb, NVN_TEXTURE_TARGET_2D);
        nvn.TextureBuilderSetFormat(&tb, NVN_FORMAT_RGBA8);
        nvn.TextureBuilderSetSize2D(&tb, w, h);
        nvn.TextureBuilderSetStorage(&tb, &g_font_pool, 0);
        const size_t need = nvn.TextureBuilderGetStorageSize(&tb);
        if (need > FontSize || !nvn.TextureInitialize(&g_font_texture, &tb)) {
            cvm::menu::Note("font texture %dx%d (%zu bytes) does not fit", w, h, need);
            return false;
        }
        g_font_texture_ok = true;
        NVNcopyRegion region = {0, 0, 0, w, h, 1};
        nvn.TextureWriteTexels(&g_font_texture, nullptr, &region, pixels);
        nvn.TextureFlushTexels(&g_font_texture, nullptr, &region);
        nvn.TexturePoolRegisterTexture(&g_texture_pool, FontId, &g_font_texture, nullptr);
        g_font_handle = nvn.DeviceGetTextureHandle(g_device, FontId, FontId);
        io.Fonts->SetTexID((ImTextureID)g_font_handle);
        io.Fonts->ClearTexData();
        g_font_px = px;
        g_font_system = added;
        g_font_glyph_hash = GlyphHash();
        cvm::menu::Note("font: %s, %d px, atlas %dx%d, %d glyph ranges", added ? "shared system font" : "built-in", px, w, h,
                        g_glyph_ranges.Size / 2);
        return true;
    }

    /* Builds the font when it is missing or no longer right; false while it can't draw yet. */
    bool EnsureFont(int px) {
        const cvm::menu::Config cfg = cvm::menu::GetConfig();
        const bool want_system = cfg.system_font && pl::LookUp();
        if (want_system && g_font_px == 0) {
            /* Ask for every shared font once, then wait up to ~2 s for the standard one. */
            if (g_font_wait == 0)
                for (int type : FontTypes)
                    pl::request_load(type);
            if (pl::load_state(0) != 1 && g_font_wait++ < 120)
                return false;
        }
        const bool stale = g_font_px != px || (want_system && g_font_glyph_hash != GlyphHash());
        if (g_font_px != 0 && !stale)
            return true;
        WaitGpu();
        return BuildFont(px, want_system);
    }

    /* ---- The menu: folders as Breeze shows them, one level at a time. ---- */

    struct Level {
        int folder; /* item index of the folder's 20000000, -1 at the top */
        int sel;
        int top;
    };
    Level g_levels[8] = {{-1, 0, 0}};
    int g_depth = 0;
    bool g_visible = false;
    bool g_wait_release = false;
    u64 g_prev_keys = 0;
    u64 g_repeat_key = 0;
    u64 g_repeat_at = 0;
    u64 g_last_tick = 0;
    u64 g_banner_start = 0;
    int g_rows[cvm::menu::MaxItems];
    int g_row_count = 0;

    constexpr u64 TickHz = 19200000;
    constexpr u64 KeyA = 1ull << 0, KeyB = 1ull << 1, KeyLeft = 1ull << 12, KeyUp = 1ull << 13, KeyRight = 1ull << 14,
                  KeyDown = 1ull << 15, StickLeft = 1ull << 16, StickUp = 1ull << 17, StickRight = 1ull << 18,
                  StickDown = 1ull << 19;

    /* The rows a folder shows: its own cheats and folders, not what its folders hold. */
    void BuildRows(int folder) {
        g_row_count = 0;
        int depth = 0;
        for (int i = folder < 0 ? 0 : folder + 1; i < (int)g_snap.count; i++) {
            const Item &it = g_snap.items[i];
            if (it.kind == cvm::menu::FolderClose) {
                if (depth == 0) {
                    if (folder >= 0)
                        break;
                    continue;
                }
                depth--;
                continue;
            }
            if (depth == 0)
                g_rows[g_row_count++] = i;
            if (it.kind == cvm::menu::FolderOpen)
                depth++;
        }
    }

    /* Cheats on inside the folder at item index folder (nested folders included). */
    int OnInside(int folder) {
        int on = 0, depth = 0;
        for (int i = folder + 1; i < (int)g_snap.count; i++) {
            const Item &it = g_snap.items[i];
            if (it.kind == cvm::menu::FolderOpen)
                depth++;
            else if (it.kind == cvm::menu::FolderClose && depth-- == 0)
                break;
            else if (it.kind == cvm::menu::Cheat && it.on)
                on++;
        }
        return on;
    }

    void Toggle(int index) {
        Item &it = g_snap.items[index];
        const bool on = !it.on;
        cvm::menu::Ask(it.name, on);
        /* Shown at once; the VM thread's reload has the last word. */
        it.on = on;
        if (on && it.group != 0)
            for (u32 i = 0; i < g_snap.count; i++)
                if ((int)i != index && g_snap.items[i].group == it.group)
                    g_snap.items[i].on = false;
    }

    /* Keys for the menu; true when it is to be drawn this frame. */
    bool UpdateMenu(u64 now) {
        const cvm::menu::Config cfg = cvm::menu::GetConfig();
        const u64 keys = cvm::RawKeys();
        const u64 pressed = keys & ~g_prev_keys;
        g_prev_keys = keys;

        if (g_wait_release) {
            /* Closed; the game gets its buttons back once every one is up. */
            if (keys == 0) {
                g_wait_release = false;
                cvm::menu::SetOpen(false);
            }
            return false;
        }
        const bool chord = cfg.open_keys != 0 && (keys & cfg.open_keys) == cfg.open_keys && (pressed & cfg.open_keys) != 0;
        if (!g_visible) {
            if (!chord)
                return false;
            g_visible = true;
            cvm::menu::SetOpen(true);
            BuildRows(g_levels[g_depth].folder);
            return true;
        }
        auto close = [&] {
            g_visible = false;
            g_wait_release = true;
        };
        if (chord) {
            close();
            return false;
        }

        BuildRows(g_levels[g_depth].folder);
        Level &lv = g_levels[g_depth];
        if (lv.sel >= g_row_count)
            lv.sel = g_row_count > 0 ? g_row_count - 1 : 0;

        /* Up / down repeat while held. */
        u64 step = 0;
        const u64 up = keys & (KeyUp | StickUp), down = keys & (KeyDown | StickDown);
        const u64 held = up ? KeyUp : down ? KeyDown : 0;
        if (held != 0 && (pressed & (KeyUp | StickUp | KeyDown | StickDown))) {
            step = held;
            g_repeat_key = held;
            g_repeat_at = now + TickHz * 35 / 100;
        } else if (held != 0 && held == g_repeat_key && now >= g_repeat_at) {
            step = held;
            g_repeat_at = now + TickHz * 7 / 100;
        } else if (held == 0) {
            g_repeat_key = 0;
        }
        if (g_row_count > 0) {
            if (step == KeyUp)
                lv.sel = lv.sel > 0 ? lv.sel - 1 : g_row_count - 1;
            else if (step == KeyDown)
                lv.sel = lv.sel + 1 < g_row_count ? lv.sel + 1 : 0;
            const int page = 10;
            if (pressed & (KeyLeft | StickLeft))
                lv.sel = lv.sel > page ? lv.sel - page : 0;
            if (pressed & (KeyRight | StickRight))
                lv.sel = lv.sel + page < g_row_count ? lv.sel + page : g_row_count - 1;
        }
        if ((pressed & KeyA) && g_row_count > 0) {
            const int index = g_rows[lv.sel];
            if (g_snap.items[index].kind == cvm::menu::FolderOpen) {
                if (g_depth + 1 < (int)(sizeof(g_levels) / sizeof(g_levels[0]))) {
                    g_levels[++g_depth] = {index, 0, 0};
                    BuildRows(index);
                }
            } else {
                Toggle(index);
            }
        } else if (pressed & KeyB) {
            if (g_depth > 0) {
                g_depth--;
                BuildRows(g_levels[g_depth].folder);
            } else {
                close();
                return false;
            }
        }
        return true;
    }

    const char *KeyName(u64 bit) {
        static const char *const names[] = {"A", "B", "X", "Y", "LS", "RS", "L", "R", "ZL", "ZR", "+", "-",
                                            "Left", "Up", "Right", "Down"};
        for (int i = 0; i < 16; i++)
            if (bit == (1ull << i))
                return names[i];
        return "?";
    }

    void ChordText(char *out, size_t cap) {
        const u64 keys = cvm::menu::GetConfig().open_keys;
        size_t n = 0;
        out[0] = 0;
        for (int i = 0; i < 16; i++)
            if (keys & (1ull << i))
                n += std::snprintf(out + n, n < cap ? cap - n : 0, "%s%s", n ? "+" : "", KeyName(1ull << i));
    }

    void DrawMenu(float w, float h) {
        const ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                                       ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoFocusOnAppearing;
        ImGui::SetNextWindowPos(ImVec2(w * 0.04f, h * 0.06f));
        /* Wide enough for the longest label (all folders, so the width does not jump), within the screen. */
        float widest = 0;
        for (u32 i = 0; i < g_snap.count; i++) {
            const Item &it = g_snap.items[i];
            const float tw = ImGui::CalcTextSize(it.name).x +
                             ImGui::CalcTextSize(it.kind == cvm::menu::FolderOpen ? ">   (99 on)" : "[on]  ").x;
            widest = tw > widest ? tw : widest;
        }
        const float pad = ImGui::GetStyle().WindowPadding.x * 2 + ImGui::GetFontSize();
        float mw = widest + pad, mh = h * 0.88f;
        const float least = w * (g_cpu_draw ? 0.40f : 0.48f), most_w = w * 0.92f;
        mw = mw < least ? least : mw > most_w ? most_w : mw;
        if (g_cpu_draw) {
            /* The CPU panel must fit FontSize at 4 bytes per texel: a wider menu is a shorter one. */
            const float most = (float)(FontSize / 4) / (mw + 2.0f) - 2.0f;
            mh = mh < most ? mh : most;
        }
        ImGui::SetNextWindowSize(ImVec2(mw, mh));
        ImGui::Begin("cheatvm", nullptr, flags);

        /* Path of open folders. */
        char path[256];
        size_t n = std::snprintf(path, sizeof(path), "Cheats");
        for (int d = 1; d <= g_depth; d++)
            n += std::snprintf(path + n, n < sizeof(path) ? sizeof(path) - n : 0, " > %s", g_snap.items[g_levels[d].folder].name);
        ImGui::TextUnformatted(path);
        /* Wrapped: the CPU-drawn menu (Switch 2) is only 40% of the screen wide. */
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.6f, 0.6f, 0.6f, 1));
        ImGui::TextWrapped("%s", g_snap.game);
        ImGui::TextWrapped("%s", g_snap.status);
        ImGui::PopStyleColor();
        if (g_snap.hint[0]) {
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.85f, 0.4f, 1));
            ImGui::TextWrapped("%s", g_snap.hint);
            ImGui::PopStyleColor();
        }
        ImGui::Separator();

        const float line = ImGui::GetTextLineHeightWithSpacing();
        const float footer = line * 1.6f;
        const int visible = (int)((ImGui::GetContentRegionAvail().y - footer) / line);
        Level &lv = g_levels[g_depth];
        if (lv.sel < lv.top)
            lv.top = lv.sel;
        if (visible > 0 && lv.sel >= lv.top + visible)
            lv.top = lv.sel - visible + 1;
        if (g_row_count == 0)
            ImGui::TextUnformatted(g_snap.count == 0 ? "no cheats" : "(empty folder)");
        ImDrawList *dl = ImGui::GetWindowDrawList();
        const float width = ImGui::GetContentRegionAvail().x;
        for (int r = lv.top; r < g_row_count && r < lv.top + visible; r++) {
            const Item &it = g_snap.items[g_rows[r]];
            const ImVec2 p = ImGui::GetCursorScreenPos();
            if (r == lv.sel)
                dl->AddRectFilled(p, ImVec2(p.x + width, p.y + line), IM_COL32(70, 110, 190, 200), 4.0f);
            if (it.kind == cvm::menu::FolderOpen) {
                const int on = OnInside(g_rows[r]);
                if (on > 0)
                    ImGui::TextColored(ImVec4(1.0f, 0.85f, 0.4f, 1), "> %s  (%d on)", it.name, on);
                else
                    ImGui::TextColored(ImVec4(1.0f, 0.85f, 0.4f, 1), "> %s", it.name);
            } else if (it.on) {
                ImGui::TextColored(ImVec4(0.45f, 1.0f, 0.45f, 1), "[on]  %s", it.name);
            } else {
                ImGui::TextColored(ImVec4(0.85f, 0.85f, 0.85f, 1), "[  ]  %s", it.name);
            }
        }
        if (g_row_count > visible && visible > 0) {
            ImGui::SetCursorPosY(ImGui::GetWindowHeight() - footer - ImGui::GetStyle().WindowPadding.y);
            ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1), "%d-%d of %d", lv.top + 1,
                               lv.top + visible < g_row_count ? lv.top + visible : g_row_count, g_row_count);
        }
        char chord[64];
        ChordText(chord, sizeof(chord));
        if (g_small_font != nullptr)
            ImGui::PushFont(g_small_font);
        ImGui::SetCursorPosY(ImGui::GetWindowHeight() - ImGui::GetTextLineHeightWithSpacing() - ImGui::GetStyle().WindowPadding.y);
        ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1), "A on/off   B back   Left/Right page   %s close", chord);
        if (g_small_font != nullptr)
            ImGui::PopFont();
        ImGui::End();
    }

    void DrawBanner(float w, float h) {
        const ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                                       ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize |
                                       ImGuiWindowFlags_NoFocusOnAppearing;
        ImGui::SetNextWindowPos(ImVec2(w * 0.02f, h * 0.03f));
        ImGui::SetNextWindowBgAlpha(0.75f);
        ImGui::Begin("cheatvm banner", nullptr, flags);
        char chord[64];
        ChordText(chord, sizeof(chord));
        ImGui::Text("cheatvm: %s opens the cheat menu", chord);
        ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1), "%s", g_snap.game);
        ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1), "%s", g_snap.status);
        if (g_snap.hint[0])
            ImGui::TextColored(ImVec4(1.0f, 0.85f, 0.4f, 1), "%s", g_snap.hint);
        ImGui::End();
    }

    void Ortho(float (&m)[4][4], float l, float r, float b, float t) {
        std::memset(m, 0, sizeof(m));
        m[0][0] = 2.f / (r - l);
        m[1][1] = 2.f / (t - b);
        m[2][2] = -0.5f;
        m[3][0] = -(r + l) / (r - l);
        m[3][1] = -(t + b) / (t - b);
        m[3][2] = 0.5f;
        m[3][3] = 1.f;
    }

    bool IsSrgb(NVNformat f) {
        return f == NVN_FORMAT_RGBA8_SRGB || f == NVN_FORMAT_RGBX8_SRGB || f == NVN_FORMAT_BGRA8_SRGB;
    }

    /* Records ImGui's draw data into our command buffer and submits it before the game's present. */
    void Render(NVNqueue *queue, const NVNtexture *target, const NVNrectangle &crop, int tex_h, bool flipped) {
        ImDrawData *dd = ImGui::GetDrawData();
        if (dd == nullptr || !dd->Valid || dd->CmdListsCount == 0)
            return;
        if ((size_t)dd->TotalVtxCount * sizeof(ImDrawVert) > VertexSize ||
            (size_t)dd->TotalIdxCount * sizeof(ImDrawIdx) + 4 * (size_t)dd->CmdListsCount > IndexSize)
            return;
        u8 *const vtx_mem = g_dynamic_mem + UboSize;
        u8 *const idx_mem = g_dynamic_mem + UboSize + VertexSize;
        const NVNbufferAddress ubo_addr = g_dynamic_addr;
        const NVNbufferAddress vtx_addr = g_dynamic_addr + UboSize;
        const NVNbufferAddress idx_addr = g_dynamic_addr + UboSize + VertexSize;

        const float W = (float)crop.width, H = (float)crop.height;
        Ubo ubo = {};
        if (flipped)
            Ortho(ubo.proj, 0, W, 0, H);
        else
            Ortho(ubo.proj, 0, W, H, 0);
        ubo.is_use_srgb = IsSrgb(nvn.TextureGetFormat(target)) ? 0 : 1;
        const int vx = crop.x;
        /* Viewport and scissor are window coordinates: from the top with an upper-left origin (crop.y as is),
           from the bottom otherwise. Separate from the projection: a crop smaller than the texture (handheld,
           dynamic resolution) put the menu half a screen low when they were tied together. */
        const bool upper = g_origin_mode == NVN_WINDOW_ORIGIN_MODE_UPPER_LEFT;
        const bool scissor_down = upper != flipped;
        const int vy = upper ? crop.y : tex_h - crop.y - crop.height;

        g_out_of_memory = false;
        nvn.CommandBufferAddCommandMemory(&g_cmd, &g_command_pool, 0, CommandSize);
        nvn.CommandBufferAddControlMemory(&g_cmd, g_control_mem, ControlSize);
        nvn.CommandBufferBeginRecording(&g_cmd);
        nvn.CommandBufferSetRenderTargets(&g_cmd, 1, &target, nullptr, nullptr, nullptr);
        nvn.CommandBufferSetViewport(&g_cmd, vx, vy, crop.width, crop.height);
        nvn.CommandBufferBindProgram(&g_cmd, &g_program, NVN_SHADER_STAGE_VERTEX_BIT | NVN_SHADER_STAGE_FRAGMENT_BIT);
        nvn.CommandBufferUpdateUniformBuffer(&g_cmd, ubo_addr, UboSize, 0, sizeof(ubo), &ubo);
        nvn.CommandBufferBindUniformBuffer(&g_cmd, NVN_SHADER_STAGE_VERTEX, 0, ubo_addr, UboSize);
        nvn.CommandBufferBindUniformBuffer(&g_cmd, NVN_SHADER_STAGE_FRAGMENT, 0, ubo_addr, UboSize);
        nvn.CommandBufferBindBlendState(&g_cmd, &g_blend);
        nvn.CommandBufferBindColorState(&g_cmd, &g_color);
        nvn.CommandBufferBindChannelMaskState(&g_cmd, &g_channel_mask);
        nvn.CommandBufferBindMultisampleState(&g_cmd, &g_multisample);
        nvn.CommandBufferBindPolygonState(&g_cmd, &g_polygon);
        nvn.CommandBufferBindDepthStencilState(&g_cmd, &g_depth_state);
        nvn.CommandBufferBindVertexAttribState(&g_cmd, 3, g_attribs);
        nvn.CommandBufferBindVertexStreamState(&g_cmd, 1, &g_stream);
        nvn.CommandBufferSetTexturePool(&g_cmd, &g_texture_pool);
        nvn.CommandBufferSetSamplerPool(&g_cmd, &g_sampler_pool);

        size_t vtx_off = 0, idx_off = 0;
        NVNtextureHandle bound = 0;
        for (int i = 0; i < dd->CmdListsCount; i++) {
            const ImDrawList *list = dd->CmdLists[i];
            const size_t vtx_size = list->VtxBuffer.Size * sizeof(ImDrawVert);
            const size_t idx_size = list->IdxBuffer.Size * sizeof(ImDrawIdx);
            std::memcpy(vtx_mem + vtx_off, list->VtxBuffer.Data, vtx_size);
            std::memcpy(idx_mem + idx_off, list->IdxBuffer.Data, idx_size);
            nvn.CommandBufferBindVertexBuffer(&g_cmd, 0, vtx_addr + vtx_off, vtx_size);
            for (const ImDrawCmd &c : list->CmdBuffer) {
                const float x0 = c.ClipRect.x > 0 ? c.ClipRect.x : 0, y0 = c.ClipRect.y > 0 ? c.ClipRect.y : 0;
                const float x1 = c.ClipRect.z < W ? c.ClipRect.z : W, y1 = c.ClipRect.w < H ? c.ClipRect.w : H;
                if (x1 <= x0 || y1 <= y0 || c.ElemCount == 0)
                    continue;
                const int sy = scissor_down ? (int)y0 : (int)(H - y1);
                nvn.CommandBufferSetScissor(&g_cmd, vx + (int)x0, vy + sy, (int)(x1 - x0), (int)(y1 - y0));
                const NVNtextureHandle tex = (NVNtextureHandle)c.GetTexID();
                if (tex != bound) {
                    bound = tex;
                    nvn.CommandBufferBindTexture(&g_cmd, NVN_SHADER_STAGE_FRAGMENT, 1, tex);
                }
                nvn.CommandBufferDrawElementsBaseVertex(&g_cmd, NVN_DRAW_PRIMITIVE_TRIANGLES, NVN_INDEX_TYPE_UNSIGNED_SHORT, (int)c.ElemCount,
                                                        idx_addr + idx_off + c.IdxOffset * sizeof(ImDrawIdx), (int)c.VtxOffset);
            }
            vtx_off += vtx_size;
            idx_off += (idx_size + 3) & ~size_t(3);
        }
        /* The game may count on the pools it bound last staying bound. */
        if (g_game_texture_pool != nullptr)
            nvn.CommandBufferSetTexturePool(&g_cmd, g_game_texture_pool);
        if (g_game_sampler_pool != nullptr)
            nvn.CommandBufferSetSamplerPool(&g_cmd, g_game_sampler_pool);
        const NVNcommandHandle handle = nvn.CommandBufferEndRecording(&g_cmd);
        if (g_out_of_memory) {
            cvm::menu::Note("menu frame ran out of command memory; not drawn");
            return;
        }
        nvn.QueueSubmitCommands(queue, 1, &handle);
        nvn.QueueFenceSync(queue, &g_sync, NVN_SYNC_CONDITION_ALL_GPU_COMMANDS_COMPLETE, 0);
        g_sync_pending = true;
    }

    bool InitImGui() {
        ImGui::SetAllocatorFunctions(Alloc, Free, nullptr);
        ImGui::CreateContext();
        ImGuiIO &io = ImGui::GetIO();
        io.IniFilename = nullptr;
        io.LogFilename = nullptr;
        io.BackendRendererName = "cheatvm_nvn";
        io.BackendFlags |= ImGuiBackendFlags_RendererHasVtxOffset;
        io.MousePos = ImVec2(-FLT_MAX, -FLT_MAX);
        ImGui::StyleColorsDark();
        ImGuiStyle &st = ImGui::GetStyle();
        st.WindowRounding = 8.0f;
        st.WindowBorderSize = 0.0f;
        st.Colors[ImGuiCol_WindowBg].w = 0.90f;
        return true;
    }

    bool g_logged_first = false;

    /* The menu can't be drawn: close it, so the game is not left without its buttons. */
    void CannotDraw() {
        if (g_visible) {
            g_visible = false;
            g_wait_release = true;
        }
    }

    /* ---- Drawing without a shader (Switch 2 games refuse the Switch 1 shader binary). ----
       ImGui's triangles are filled on the CPU into g_font_mem (the font texture's pool is not needed then: the
       font atlas stays on the CPU, in g_dynamic_mem), and CommandBufferCopyBufferToTexture puts that rectangle
       on the window texture. Copies can't blend with the game: the panel is opaque. Verified on OoT (Switch 2)
       with a test rectangle first: window RGBA8, origin upper left, copy region y counted from the top. */

    bool g_cpu_logged = false;

    /* 4 bytes per texel formats the panel can be converted to; 0 = not handled. */
    int CpuFormat(NVNformat f) {
        switch (f) {
        case NVN_FORMAT_RGBA8: case NVN_FORMAT_RGBA8_SRGB: case NVN_FORMAT_RGBX8: case NVN_FORMAT_RGBX8_SRGB:
            return 1;
        case NVN_FORMAT_BGRA8: case NVN_FORMAT_BGRA8_SRGB:
            return 2;
        case NVN_FORMAT_RGB10A2:
            return 3;
        default:
            return 0;
        }
    }

    inline float Edge(float ax, float ay, float bx, float by, float px, float py) {
        return (bx - ax) * (py - ay) - (by - ay) * (px - ax);
    }

    /* One ImGui triangle into buf (bw x bh, at display bx,by), clipped to clip (display coordinates). */
    void CpuTriangle(u32 *buf, int bw, int bh, float ox, float oy, const ImDrawVert &a, const ImDrawVert &b,
                     const ImDrawVert &c, const ImVec4 &clip) {
        const float ax = a.pos.x - ox, ay = a.pos.y - oy, bx = b.pos.x - ox, by = b.pos.y - oy, cx = c.pos.x - ox,
                    cy = c.pos.y - oy;
        const float area = Edge(ax, ay, bx, by, cx, cy);
        if (area > -1e-6f && area < 1e-6f)
            return;
        const float inv = 1.0f / area;
        float lx = ax < bx ? ax : bx, hx = ax > bx ? ax : bx, ly = ay < by ? ay : by, hy = ay > by ? ay : by;
        lx = cx < lx ? cx : lx; hx = cx > hx ? cx : hx; ly = cy < ly ? cy : ly; hy = cy > hy ? cy : hy;
        const float clx = clip.x - ox, cly = clip.y - oy, chx = clip.z - ox, chy = clip.w - oy;
        lx = lx > clx ? lx : clx; ly = ly > cly ? ly : cly; hx = hx < chx ? hx : chx; hy = hy < chy ? hy : chy;
        int x0 = (int)lx, y0 = (int)ly, x1 = (int)(hx + 1.0f), y1 = (int)(hy + 1.0f);
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > bw) x1 = bw;
        if (y1 > bh) y1 = bh;
        if (x0 >= x1 || y0 >= y1)
            return;
        const bool flat = a.col == b.col && a.col == c.col;
        const float fw = (float)g_cpu_font_w, fh = (float)g_cpu_font_h;
        for (int py = y0; py < y1; py++) {
            const float sy = py + 0.5f;
            if (sy < cly || sy >= chy)
                continue;
            u32 *row = buf + (size_t)py * bw;
            for (int px = x0; px < x1; px++) {
                const float sx = px + 0.5f;
                if (sx < clx || sx >= chx)
                    continue;
                const float w0 = Edge(bx, by, cx, cy, sx, sy) * inv, w1 = Edge(cx, cy, ax, ay, sx, sy) * inv;
                const float w2 = 1.0f - w0 - w1;
                if (w0 < 0 || w1 < 0 || w2 < 0)
                    continue;
                u32 col = a.col;
                if (!flat) {
                    u32 out = 0;
                    for (int sh = 0; sh < 32; sh += 8) {
                        const float v = w0 * ((a.col >> sh) & 0xFF) + w1 * ((b.col >> sh) & 0xFF) + w2 * ((c.col >> sh) & 0xFF);
                        out |= (u32)(v + 0.5f) << sh;
                    }
                    col = out;
                }
                u32 sa = col >> 24;
                if (g_cpu_font != nullptr) {
                    const float u = w0 * a.uv.x + w1 * b.uv.x + w2 * c.uv.x, v = w0 * a.uv.y + w1 * b.uv.y + w2 * c.uv.y;
                    int tx = (int)(u * fw), ty = (int)(v * fh);
                    tx = tx < 0 ? 0 : (tx >= g_cpu_font_w ? g_cpu_font_w - 1 : tx);
                    ty = ty < 0 ? 0 : (ty >= g_cpu_font_h ? g_cpu_font_h - 1 : ty);
                    sa = sa * g_cpu_font[(size_t)ty * g_cpu_font_w + tx] / 255;
                }
                if (sa == 0)
                    continue;
                const u32 d = row[px];
                u32 out = 0xFF000000u;
                for (int sh = 0; sh < 24; sh += 8) {
                    const u32 s = (col >> sh) & 0xFF, dd = (d >> sh) & 0xFF;
                    out |= ((s * sa + dd * (255 - sa)) / 255) << sh;
                }
                row[px] = out;
            }
        }
    }

    /* The menu or banner drawn by the CPU, then copied onto the window texture. */
    void CpuRender(NVNqueue *queue, const NVNtexture *target, const NVNrectangle &crop, int tex_h) {
        ImDrawData *dd = ImGui::GetDrawData();
        if (dd == nullptr || !dd->Valid || dd->CmdListsCount == 0)
            return;
        const NVNformat fmt = nvn.TextureGetFormat(target);
        const int conv = CpuFormat(fmt);
        if (conv == 0) {
            if (!g_cpu_logged)
                cvm::menu::Note("no menu: window format %d is not one the CPU drawing handles", (int)fmt);
            g_cpu_logged = true;
            CannotDraw();
            return;
        }
        /* The panel: the vertices' bounds, inside the display. */
        float lx = 1e9f, ly = 1e9f, hx = -1e9f, hy = -1e9f;
        for (int i = 0; i < dd->CmdListsCount; i++)
            for (const ImDrawVert &v : dd->CmdLists[i]->VtxBuffer) {
                lx = v.pos.x < lx ? v.pos.x : lx; hx = v.pos.x > hx ? v.pos.x : hx;
                ly = v.pos.y < ly ? v.pos.y : ly; hy = v.pos.y > hy ? v.pos.y : hy;
            }
        int bx = lx < 0 ? 0 : (int)lx, by = ly < 0 ? 0 : (int)ly;
        int ex = hx > crop.width ? crop.width : (int)(hx + 1.0f), ey = hy > crop.height ? crop.height : (int)(hy + 1.0f);
        int bw = ex - bx, bh = ey - by;
        if (bw <= 0 || bh <= 0)
            return;
        if ((size_t)bw * bh * 4 > FontSize)
            bh = (int)(FontSize / 4 / (size_t)bw);
        const bool upper = g_origin_mode == NVN_WINDOW_ORIGIN_MODE_UPPER_LEFT;
        if (!g_cpu_logged) {
            g_cpu_logged = true;
            cvm::menu::Note("CPU drawing: window format %d, panel %dx%d at %d,%d, origin %s", (int)fmt, bw, bh, bx, by,
                            upper ? "upper left" : "lower left (rows flipped, untested)");
        }

        u64 h = 0xCBF29CE484222325ull;
        auto mix = [&h](const void *p, size_t n) {
            for (size_t k = 0; k < n; k++)
                h = (h ^ ((const u8 *)p)[k]) * 0x100000001B3ull;
        };
        const int box[4] = {bx, by, bw, bh};
        mix(box, sizeof(box));
        for (int i = 0; i < dd->CmdListsCount; i++) {
            const ImDrawList *list = dd->CmdLists[i];
            mix(list->VtxBuffer.Data, list->VtxBuffer.Size * sizeof(ImDrawVert));
            mix(list->IdxBuffer.Data, list->IdxBuffer.Size * sizeof(ImDrawIdx));
        }
        u32 *const buf = reinterpret_cast<u32 *>(g_font_mem);
        if (h != g_cpu_hash) {
            g_cpu_hash = h;
            for (size_t k = 0; k < (size_t)bw * bh; k++)
                buf[k] = 0xFF000000u;
            for (int i = 0; i < dd->CmdListsCount; i++) {
                const ImDrawList *list = dd->CmdLists[i];
                for (const ImDrawCmd &c : list->CmdBuffer) {
                    if (c.UserCallback != nullptr || c.ElemCount == 0)
                        continue;
                    const ImDrawIdx *idx = list->IdxBuffer.Data + c.IdxOffset;
                    const ImDrawVert *vtx = list->VtxBuffer.Data + c.VtxOffset;
                    for (u32 k = 0; k + 2 < c.ElemCount; k += 3)
                        CpuTriangle(buf, bw, bh, (float)bx, (float)by, vtx[idx[k]], vtx[idx[k + 1]], vtx[idx[k + 2]], c.ClipRect);
                }
            }
            if (conv == 2) {
                for (size_t k = 0; k < (size_t)bw * bh; k++) {
                    const u32 p = buf[k];
                    buf[k] = (p & 0xFF00FF00u) | ((p & 0xFF) << 16) | ((p >> 16) & 0xFF);
                }
            } else if (conv == 3) {
                for (size_t k = 0; k < (size_t)bw * bh; k++) {
                    const u32 p = buf[k];
                    const u32 r = p & 0xFF, g = (p >> 8) & 0xFF, b = (p >> 16) & 0xFF;
                    buf[k] = (r * 1023 / 255) | ((g * 1023 / 255) << 10) | ((b * 1023 / 255) << 20) | (3u << 30);
                }
            }
            if (!upper) {
                for (int y = 0; y < bh / 2; y++) {
                    u32 *r0 = buf + (size_t)y * bw, *r1 = buf + (size_t)(bh - 1 - y) * bw;
                    for (int x = 0; x < bw; x++) {
                        const u32 t = r0[x];
                        r0[x] = r1[x];
                        r1[x] = t;
                    }
                }
            }
        }
        const int dy = upper ? crop.y + by : tex_h - (crop.y + by) - bh;
        g_out_of_memory = false;
        nvn.CommandBufferAddCommandMemory(&g_cmd, &g_command_pool, 0, CommandSize);
        nvn.CommandBufferAddControlMemory(&g_cmd, g_control_mem, ControlSize);
        nvn.CommandBufferBeginRecording(&g_cmd);
        const NVNcopyRegion region = {crop.x + bx, dy, 0, bw, bh, 1};
        nvn.CommandBufferCopyBufferToTexture(&g_cmd, nvn.MemoryPoolGetBufferAddress(&g_font_pool), target, nullptr, &region,
                                             NVN_COPY_FLAGS_NONE);
        const NVNcommandHandle handle = nvn.CommandBufferEndRecording(&g_cmd);
        if (g_out_of_memory)
            return;
        nvn.QueueSubmitCommands(queue, 1, &handle);
        nvn.QueueFenceSync(queue, &g_sync, NVN_SYNC_CONDITION_ALL_GPU_COMMANDS_COMPLETE, 0);
        g_sync_pending = true;
    }

    NVNrectangle g_last_crop = {0, 0, 0, 0};
    int g_crop_changes = 0;

    void Frame(NVNqueue *queue, NVNwindow *window, int index) {
        const u64 now = svcGetSystemTick();
        if (g_device == nullptr || g_state == State::Failed)
            return;

        const u32 generation = g_snap.generation;
        cvm::menu::Read(g_snap);
        if (g_snap.generation != generation) {
            /* Reloaded: the open folders must still be folders, or back to the top. */
            for (int d = 1; d <= g_depth; d++) {
                const int f = g_levels[d].folder;
                if (f >= (int)g_snap.count || g_snap.items[f].kind != cvm::menu::FolderOpen) {
                    g_depth = 0;
                    break;
                }
            }
            if (g_visible)
                BuildRows(g_levels[g_depth].folder);
        }
        /* From the first button after the cheats load: the game's logos come long before anyone looks. */
        if (g_banner_start == 0 && g_snap.generation != 0 && cvm::RawKeys() != 0)
            g_banner_start = now;
        const bool menu = UpdateMenu(now);
        const cvm::menu::Config cfg = cvm::menu::GetConfig();
        const bool banner = !menu && cfg.banner && g_banner_start != 0 && now - g_banner_start < TickHz * 10;
        if (!menu && !banner)
            return;

        if (g_state == State::Waiting) {
            if (!InitGpu() || !InitImGui()) {
                g_state = State::Failed;
                cvm::menu::Note("no menu: GPU setup failed");
                CannotDraw();
                cvm::menu::SetOpen(false);
                return;
            }
            g_state = State::Ready;
            if (g_cpu_draw) {
                /* Copies can't blend: square corners and opaque backgrounds, so nothing shows the black fill. */
                ImGuiStyle &st = ImGui::GetStyle();
                st.WindowRounding = 0.0f;
                st.Colors[ImGuiCol_WindowBg].w = 1.0f;
            }
        }
        const Textures *t = Find(g_windows, window);
        if (t == nullptr || index < 0 || index >= t->count) {
            static bool noted = false;
            if (!noted)
                cvm::menu::Note("present of window %p texture %d: textures not seen, nothing drawn", window, index);
            noted = true;
            CannotDraw();
            return;
        }
        const NVNtexture *target = t->tex[index];
        const int tex_w = nvn.TextureGetWidth(target), tex_h = nvn.TextureGetHeight(target);
        NVNrectangle crop = {0, 0, 0, 0};
        nvn.WindowGetCrop(window, &crop);
        if (crop.width <= 0 || crop.height <= 0 || crop.width > tex_w || crop.height > tex_h)
            crop = {0, 0, tex_w, tex_h};
        /* Test only: a smaller crop at the top left, as handheld mode gives. */
        if (cfg.test_crop_w > 0 && cfg.test_crop_h > 0 && cfg.test_crop_w <= tex_w && cfg.test_crop_h <= tex_h)
            crop = {0, 0, cfg.test_crop_w, cfg.test_crop_h};
        /* Measured on FFRS (UE4, origin upper left): drawing flipped came out upside down, so auto never flips. */
        const bool flipped = cfg.flip > 0;
        if (!g_logged_first) {
            g_logged_first = true;
            g_last_crop = crop;
            cvm::menu::Note("first draw: window %dx%d (crop %d,%d %dx%d), format %d, origin %s%s, %u devices", tex_w, tex_h, crop.x,
                            crop.y, crop.width, crop.height, (int)nvn.TextureGetFormat(target),
                            g_origin_mode == NVN_WINDOW_ORIGIN_MODE_UPPER_LEFT ? "upper left" : "lower left",
                            flipped ? ", drawn flipped" : "", g_devices);
        } else {
            /* Handheld / docked switches and dynamic resolution change the crop: noted, a few times. */
            const NVNrectangle &last = g_last_crop;
            if ((crop.x != last.x || crop.y != last.y || crop.width != last.width || crop.height != last.height) && g_crop_changes < 8) {
                g_crop_changes++;
                cvm::menu::Note("window %dx%d now crop %d,%d %dx%d", tex_w, tex_h, crop.x, crop.y, crop.width, crop.height);
            }
            g_last_crop = crop;
        }

        WaitGpu();
        if (!EnsureFont(crop.height / 30 > 12 ? crop.height / 30 : 12))
            return;
        ImGuiIO &io = ImGui::GetIO();
        io.DisplaySize = ImVec2((float)crop.width, (float)crop.height);
        const u64 dt = g_last_tick ? now - g_last_tick : TickHz / 60;
        io.DeltaTime = dt > 0 ? (float)dt / TickHz : 1.0f / 60;
        g_last_tick = now;
        ImGui::NewFrame();
        if (menu)
            DrawMenu(io.DisplaySize.x, io.DisplaySize.y);
        else
            DrawBanner(io.DisplaySize.x, io.DisplaySize.y);
        ImGui::Render();
        if (g_cpu_draw)
            CpuRender(queue, target, crop, tex_h);
        else
            Render(queue, target, crop, tex_h, flipped);
        if (g_alloc_failures) {
            cvm::menu::Note("ImGui heap full (%u failed allocations)", g_alloc_failures);
            g_alloc_failures = 0;
        }
    }

    void Present(NVNqueue *queue, NVNwindow *window, int index) {
        Frame(queue, window, index);
        g_present(queue, window, index);
    }
}

HOOK_DEFINE_TRAMPOLINE(BootstrapHook) {
    static void *Callback(const char *name) {
        void *p = Orig(name);
        return reinterpret_cast<void *>(Wrap(name, reinterpret_cast<PFNNVNGENERICFUNCPTRPROC>(p)));
    }
};

namespace cvm::menu {
    void Install() {
        uintptr_t p = 0;
        if (R_FAILED(nn::ro::LookupSymbol(&p, "nvnBootstrapLoader")) || p == 0) {
            Note("nvnBootstrapLoader not found: no menu in this game");
            return;
        }
        BootstrapHook::InstallAtPtr(p);
        Note("nvnBootstrapLoader hooked");
    }
}
#endif
